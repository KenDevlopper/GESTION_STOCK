-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 08, 2024 at 07:17 AM
-- Server version: 8.2.0
-- PHP Version: 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gestion_stock`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom_categorie` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `nom_categorie`) VALUES
(46, 'boisson');

-- --------------------------------------------------------

--
-- Table structure for table `imprimerie`
--

DROP TABLE IF EXISTS `imprimerie`;
CREATE TABLE IF NOT EXISTS `imprimerie` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `taille` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `type_papier` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `categorie` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `prix` decimal(10,2) NOT NULL,
  `date_creation` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `imprimerie`
--

INSERT INTO `imprimerie` (`id`, `type`, `taille`, `type_papier`, `categorie`, `prix`, `date_creation`) VALUES
(8, 'Couleur', '8x11', 'Papier blanc', 'Impression', 50.00, '2024-10-07 17:31:05');

-- --------------------------------------------------------

--
-- Table structure for table `produits`
--

DROP TABLE IF EXISTS `produits`;
CREATE TABLE IF NOT EXISTS `produits` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom_produit` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `prix_unite` decimal(10,2) NOT NULL,
  `quantite_produit` int NOT NULL,
  `id_categorie` int DEFAULT NULL,
  `caisse` int NOT NULL,
  `prix_caisse` decimal(10,2) NOT NULL,
  `date_enregistrement` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `nom_utilisateur` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_categorie` (`id_categorie`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produits`
--

INSERT INTO `produits` (`id`, `nom_produit`, `description`, `prix_unite`, `quantite_produit`, `id_categorie`, `caisse`, `prix_caisse`, `date_enregistrement`, `nom_utilisateur`) VALUES
(40, 'Robusto', 'energissant', 125.00, 17, 46, 0, 3000.00, '2024-10-07 16:06:49', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `produit_impression`
--

DROP TABLE IF EXISTS `produit_impression`;
CREATE TABLE IF NOT EXISTS `produit_impression` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom_client` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `type_produit` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `quantite` int NOT NULL,
  `prix` decimal(10,2) NOT NULL,
  `prix_total` decimal(10,2) NOT NULL,
  `nom_utilisateur` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `date_vente` datetime NOT NULL,
  `is_deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produit_impression`
--

INSERT INTO `produit_impression` (`id`, `nom_client`, `type_produit`, `description`, `quantite`, `prix`, `prix_total`, `nom_utilisateur`, `date_vente`, `is_deleted`) VALUES
(5, 'Joseph Decimus', 'Papier', 'blanc', 10, 25.00, 250.00, 'Saintilnord Ancelinio', '2024-10-07 17:52:04', 1),
(6, 'Pierre Luckson', 'Enveloppe', 'Jaune', 2, 50.00, 100.00, 'Saintilnord Ancelinio', '2024-10-07 17:53:19', 0),
(7, 'Pierre Luckson', 'Papier', 'Jaune', 2, 50.00, 100.00, 'Joseph', '2024-10-08 06:50:31', 0);

-- --------------------------------------------------------

--
-- Table structure for table `service_impression`
--

DROP TABLE IF EXISTS `service_impression`;
CREATE TABLE IF NOT EXISTS `service_impression` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `nom_client` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `taille` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `type_papier` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `categorie` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `quantite` int NOT NULL,
  `prix` decimal(10,2) NOT NULL,
  `date_impression` datetime DEFAULT NULL,
  `nom_utilisateur` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `is_deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `service_impression`
--

INSERT INTO `service_impression` (`id`, `type`, `nom_client`, `taille`, `type_papier`, `categorie`, `quantite`, `prix`, `date_impression`, `nom_utilisateur`, `is_deleted`) VALUES
(18, 'Couleur', 'Lounedala Dolcine', '8x11', 'Papier blanc', 'Impression', 10, 500.00, '2024-10-07 17:32:06', 'Saintilnord Ancelinio', 1),
(19, 'Couleur', 'Joseph Decimus', '8x11', 'Papier blanc', 'Impression', 90, 4500.00, '2024-10-08 06:37:01', 'Joseph', 0);

-- --------------------------------------------------------

--
-- Table structure for table `service_recharge`
--

DROP TABLE IF EXISTS `service_recharge`;
CREATE TABLE IF NOT EXISTS `service_recharge` (
  `id` int NOT NULL AUTO_INCREMENT,
  `numero_carte` int NOT NULL,
  `appareil` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `type_recharge` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `quantite` int NOT NULL,
  `prix_total` decimal(10,2) NOT NULL,
  `date_recharge` datetime NOT NULL,
  `nom_utilisateur` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `is_deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `service_recharge`
--

INSERT INTO `service_recharge` (`id`, `numero_carte`, `appareil`, `type_recharge`, `quantite`, `prix_total`, `date_recharge`, `nom_utilisateur`, `is_deleted`) VALUES
(9, 1, 'Telephone', 'Avec chargeur', 12, 110.00, '2024-10-08 06:14:02', 'Joseph', 0);

-- --------------------------------------------------------

--
-- Table structure for table `utilisateurs`
--

DROP TABLE IF EXISTS `utilisateurs`;
CREATE TABLE IF NOT EXISTS `utilisateurs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom_utilisateur` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `mot_de_passe` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `role` enum('admin','employe') COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `utilisateurs`
--

INSERT INTO `utilisateurs` (`id`, `nom_utilisateur`, `mot_de_passe`, `role`) VALUES
(36, 'Luckson', '$2y$10$PLOSt0KeTiiuQenrGxcpJuL0BtQvcJI2CNXoxTfY1/Gy2XueN6YBS', 'employe'),
(35, 'Saintilnord Ancelinio', '$2y$10$6Wu7PqPgvVprVwiFRxXfceLRv4rTTgtQW9vbQzT9HxU1nCbp3Aylm', 'admin'),
(34, 'Joseph', '$2y$10$RC4bIOGPtLaXhuHXIuAu.uVQDNa2YqC0ykdeI9hR.YIK2ZrKs2Fxq', 'employe'),
(33, 'Nuacky', '$2y$10$jtD5DgVoAqHvV/kdZDQVN.FBUvCORCFxu7J6xmuLRf.1v2sI3dt42', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `ventes`
--

DROP TABLE IF EXISTS `ventes`;
CREATE TABLE IF NOT EXISTS `ventes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom_client` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `produit_id` int DEFAULT NULL,
  `quantite` int DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `prix_total` decimal(10,2) DEFAULT NULL,
  `balance` decimal(10,0) NOT NULL,
  `date_vente` date DEFAULT NULL,
  `nom_utilisateur` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `id_eau` int NOT NULL,
  `is_deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `produit_id` (`produit_id`),
  KEY `fk_eau` (`id_eau`)
) ENGINE=MyISAM AUTO_INCREMENT=251 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ventes`
--

INSERT INTO `ventes` (`id`, `nom_client`, `produit_id`, `quantite`, `type`, `prix_total`, `balance`, `date_vente`, `nom_utilisateur`, `id_eau`, `is_deleted`) VALUES
(248, 'Junior', 40, 10, 'unite', 1250.00, 1000, '2024-10-07', 'Nuacky', 0, 1),
(249, 'Judnel', 40, 10, 'unite', 1250.00, 0, '2024-10-07', 'Saintilnord Ancelinio', 0, 0),
(250, 'Jovenel', 40, 10, 'unite', 1250.00, 250, '2024-10-08', 'Joseph', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ventes_eau`
--

DROP TABLE IF EXISTS `ventes_eau`;
CREATE TABLE IF NOT EXISTS `ventes_eau` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom_client` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `type_eau` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `quantite` int NOT NULL,
  `prix_total` decimal(10,2) NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `date_vente` date NOT NULL,
  `nom_utilisateur` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `is_deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ventes_eau`
--

INSERT INTO `ventes_eau` (`id`, `nom_client`, `type_eau`, `quantite`, `prix_total`, `balance`, `date_vente`, `nom_utilisateur`, `is_deleted`) VALUES
(13, 'Joseph Decimus', 'unite', 2, 100.00, 0.00, '2024-10-07', 'Nuacky', 1),
(14, 'Lounedala Dolcine', 'Gros Sachet', 2, 500.00, 0.00, '2024-10-07', 'Saintilnord Ancelinio', 1),
(15, 'Jovenel Moise', 'unite', 20, 110.00, 0.00, '2024-10-08', 'Joseph', 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
