<?php
session_start();
require '..\..\config\database.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $role = $_POST['role'];

    // Vérification si les mots de passe correspondent
    if ($password !== $confirm_password) {
        $error = "Les mots de passe ne correspondent pas.";
    } else {
        // Vérifier si le nom d'utilisateur existe déjà
        $query = $conn->prepare("SELECT id FROM utilisateurs WHERE nom_utilisateur = ?");
        $query->bind_param('s', $username);
        $query->execute();
        $query->store_result();

        if ($query->num_rows > 0) {
            $error = "Le nom d'utilisateur existe déjà.";
        } else {
            // Hachage du mot de passe
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);

            // Insertion de l'utilisateur dans la base de données
            $stmt = $conn->prepare("INSERT INTO utilisateurs (nom_utilisateur, mot_de_passe, role) VALUES (?, ?, ?)");
            $stmt->bind_param('sss', $username, $hashed_password, $role);
            $stmt->execute();
            $stmt->close();

            // Enregistrer le message de succès dans la session
            $_SESSION['success_message'] = "Inscription réussie. Veuillez vous connecter.";

            echo "Inscription réussie.";
            exit();
        }

        $query->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../css/style.css">
    <link rel="stylesheet" href="../../fontawesome/css/all.min.css">
    <title>Inscription</title>
</head>

<body>
    <div class="register-container">
        <h2>Inscription</h2>
        <?php
        if (isset($error)) {
            echo "<p class='error'><i class='fas fa-exclamation-circle'></i> $error</p>";
        }
        if (isset($success)) {
            echo "<p class='success'><i class='fas fa-check-circle'></i> $success</p>";
        }
        ?>
        <form action="check.php" method="post">
            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="text" id="username" name="username" placeholder="Nom d'utilisateur" required>
            </div>

            <div class="input-group">
                <i class="fas fa-lock"></i>
                <input type="password" id="password" name="password" placeholder="Mot de passe" required>
            </div>

            <div class="input-group">
                <i class="fas fa-lock"></i>
                <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirmer le mot de passe" required>
            </div>

            <div class="input-group">
                <i class="fas fa-user-tag"></i>
                <select id="role" name="role" required>
                    <option value="admin">Admin</option>
                    <option value="employe">Employé</option>
                </select>
            </div>

            <button type="submit">S'inscrire</button>
        </form>

    </div>
</body>

</html>