<footer>
  <small>&copy; <?php echo date("Y"); ?> Suprise C&M Multi-Services. Tous droits réservés.</small>
</footer>