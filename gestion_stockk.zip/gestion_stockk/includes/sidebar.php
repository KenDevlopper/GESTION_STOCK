<nav class="sidebar">
  <div class="sidebar-header">
    <i class="fas fa-user-circle" style="font-size: 3rem; margin-bottom: 10px"></i>
    <?php
    if (isset($_SESSION['nom_utilisateur'])) {
      echo "<h4>Bienvenue, " . htmlspecialchars($_SESSION['nom_utilisateur']) . "</h4>";
    } else {
      echo "<p>Utilisateur non connecté</p>";
    }
    ?>
  </div>
  <div class="diviseur"></div>
  <ul class="nav-links">
    <li>
      <a href="dashboard.php?page=dashboard" class="dashboardText <?php echo (basename($_SERVER['PHP_SELF']) == 'dashboard.php') ? 'active' : ''; ?>">
        <i class="fas fa-tachometer-alt"></i> Dashboard <i class="fa-circle"></i>
      </a>
    </li>

    <?php
    // Vérification pour les pages de gestion des produits
    $active_produits = (basename($_SERVER['PHP_SELF']) == 'ajouter_categorie.php' ||
      basename($_SERVER['PHP_SELF']) == 'ajouter_produits.php' ||
      basename($_SERVER['PHP_SELF']) == 'lister_produits.php');
    ?>

    <li>
      <a href="#" class="menu-toggle <?php echo $active_produits ? 'active' : ''; ?>">
        <i class="fas fa-box"></i> Gestion des Produits
        <i class="fas fa-chevron-down accordion-icon"></i>
      </a>
      <ul class="sub-menu">
        <li><a href="ajouter_categorie.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'ajouter_categorie.php') ? 'active' : ''; ?>">Ajouter Catégorie</a></li>
        <li><a href="ajouter_produits.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'ajouter_produits.php') ? 'active' : ''; ?>">&#9900 Ajouter Produit</a></li>
        <li><a href="lister_produits.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'lister_produits.php') ? 'active' : ''; ?>">&#9900 Lister Produits</a></li>
      </ul>
    </li>

    <?php
    // Vérification pour la gestion des stocks
    $active_stocks = (basename($_SERVER['PHP_SELF']) == 'ravitaillement_stock.php');
    ?>

    <li>
      <a href="#" class="menu-toggle <?php echo $active_stocks ? 'active' : ''; ?>">
        <i class="fas fa-warehouse"></i> Gestion des Stocks
        <i class="fas fa-chevron-down accordion-icon"></i>
      </a>
      <ul class="sub-menu">
        <li><a href="ravitaillement_stock.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'ravitaillement_stock.php') ? 'active' : ''; ?>">&#9900 Ravitaillement de Stock</a></li>
      </ul>
    </li>


    <?php
    // Vérification pour la gestion des ventes
    $active_ventes = (basename($_SERVER['PHP_SELF']) == 'ajouter_vente.php' ||
      basename($_SERVER['PHP_SELF']) == 'lister_ventes.php' ||
      basename($_SERVER['PHP_SELF']) == 'vente_eau.php');
    ?>

    <li>
      <a href="#" class="menu-toggle <?php echo $active_ventes ? 'active' : ''; ?>">
        <i class="fas fa-shopping-cart"></i> Gestion des Ventes
        <i class="fas fa-chevron-down accordion-icon"></i>
      </a>
      <ul class="sub-menu">
        <li><a href="ajouter_vente.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'ajouter_vente.php') ? 'active' : ''; ?>">&#9900 Ajouter vente </a></li>
        <li><a href="vente_eau.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'vente_eau.php') ? 'active' : ''; ?>">&#9900 Ventes d'eau sachet</a></li>
        <li><a href="lister_ventes.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'lister_ventes.php') ? 'active' : ''; ?>">&#9900 Lister ventes </a></li>
      </ul>
    </li>
    <?php
    // Vérification pour la gestion des rapports
    $active_rapports = (basename($_SERVER['PHP_SELF']) == 'generer_rapport.php' ||
      basename($_SERVER['PHP_SELF']) == 'rapport_previsionel.php');
    ?>

    <li>
      <a href="#" class="menu-toggle <?php echo $active_rapports ? 'active' : ''; ?>">
        <i class="fas fa-chart-line"></i> Rapports
        <i class="fas fa-chevron-down accordion-icon"></i>
      </a>
      <ul class="sub-menu">
        <li><a href="generer_rapport.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'generer_rapport.php') ? 'active' : ''; ?>">&#9900 Rapport de vente</a></li>
        <li><a href="rapport_previsionel.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'rapport_previsionel.php') ? 'active' : ''; ?>">&#9900 Rapport Previsionel</a></li>
      </ul>
    </li>

    <?php
    // Vérification pour la gestion des impressions
    $active_impression = (basename($_SERVER['PHP_SELF']) == 'data_impression.php' ||
      basename($_SERVER['PHP_SELF']) == 'impression.php' ||
      basename($_SERVER['PHP_SELF']) == 'listes_service_impression.php' ||
      basename($_SERVER['PHP_SELF']) == 'produit_impression.php' ||
      basename($_SERVER['PHP_SELF']) == 'liste_ventes_service.php' ||
      basename($_SERVER['PHP_SELF']) == 'liste_ventes_service.php');
    ?>

    <li>
      <a href="#" class="menu-toggle <?php echo $active_impression ? 'active' : ''; ?>">
        <i class="fas fa-print"></i> Gestion Imprimerie
        <i class="fas fa-chevron-down accordion-icon"></i>
      </a>
      <ul class="sub-menu">
        <li><a href="data_impression.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'data_impression.php') ? 'active' : ''; ?>">&#9900 Donnée Impression</a></li>
        <li><a href="impression.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'impression.php') ? 'active' : ''; ?>">&#9900 Service Impression</a></li>
        <li><a href="listes_service_impression.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'listes_service_impression.php') ? 'active' : ''; ?>">&#9900 Listes Service</a></li>
        <li><a href="produit_impression.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'produit_impression.php') ? 'active' : ''; ?>">&#9900 Ventes Produits Imp</a></li>
        <li><a href="liste_produits_impression.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'liste_produits_impression.php') ? 'active' : ''; ?>">&#9900 Listes ventes P. Imp </a></li>
        <li><a href="rapport_impression.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'rapport_impression.php') ? 'active' : ''; ?>">&#9900 Rapport Imprimerie </a></li>

      </ul>
    </li>

    <?php
    // Vérification pour la gestion des services de recharge
    $active_recharge = (basename($_SERVER['PHP_SELF']) == 'service_reharge.php' ||
      basename($_SERVER['PHP_SELF']) == 'lister_recharge.php' ||
      basename($_SERVER['PHP_SELF']) == 'rapport_recharge.php');
    ?>

    <li>
      <a href="#" class="menu-toggle <?php echo $active_recharge ? 'active' : ''; ?>">
        <i class="fas fa-plug"></i> Service recharge
        <i class="fas fa-chevron-down accordion-icon"></i>
      </a>
      <ul class="sub-menu">
        <li><a href="service_recharge.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'service_recharge.php') ? 'active' : ''; ?>">&#9900 Service recharge</a></li>
        <li><a href="lister_recharge.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'lister_recharge.php') ? 'active' : ''; ?>">&#9900 Lister recharge</a></li>
        <li><a href="rapport_recharge.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'rapport_recharge.php') ? 'active' : ''; ?>">&#9900 Rapport recharge</a></li>
      </ul>
    </li>



    <?php
    // Vérification pour la gestion des Employes
    $active_employe = (basename($_SERVER['PHP_SELF']) == 'ajouter_employe.php' ||
      basename($_SERVER['PHP_SELF']) == 'lister_employes.php');
    ?>

    <li>
      <a href="#" class="menu-toggle <?php echo $active_employe ? 'active' : ''; ?>">
        <i class="fas fa-user-tie"></i> Employés
        <i class="fas fa-chevron-down accordion-icon"></i>
      </a>
      <ul class="sub-menu">
        <li><a href="ajouter_employe.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'ajouter_employe.php') ? 'active' : ''; ?>">&#9900 Ajouter Employé</a></li>
        <li><a href="lister_employes.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'lister_employes.php') ? 'active' : ''; ?>">&#9900 Lister Employés</a></li>
      </ul>
    </li>

    <?php
    // Vérification pour la gestion des parametres
    $active_parametre = (basename($_SERVER['PHP_SELF']) == 'securite.php');
    ?>

    <li>
      <a href="#" class="menu-toggle <?php echo $active_parametre ? 'active' : ''; ?>">
        <i class="fas fa-cogs"></i> Paramètres
        <i class="fas fa-chevron-down accordion-icon"></i>
      </a>
      <ul class="sub-menu">
        <li><a href="securite.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'securite.php') ? 'active' : ''; ?>">&#9900 Sécurité</a></li>
      </ul>
    </li>


  </ul>
</nav>