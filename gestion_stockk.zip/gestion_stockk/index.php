<?php
session_start();
require 'config/database.php';

$success_message = "";

// Vérifier s'il y a un message de succès stocké dans la session
if (isset($_SESSION['success_message'])) {
    $success_message = $_SESSION['success_message'];
    unset($_SESSION['success_message']); // Supprimer le message de la session après l'affichage
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = $conn->prepare("SELECT * FROM utilisateurs WHERE nom_utilisateur = ?");
    $query->bind_param('s', $username);
    $query->execute();
    $result = $query->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['mot_de_passe'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['nom_utilisateur'] = $user['nom_utilisateur'];
        $_SESSION['role'] = $user['role'];

        // Redirection en fonction du rôle
        if ($user['role'] === 'admin') {
            header("Location: pages/dashboard.php");
        } elseif ($user['role'] === 'employe') {
            header("Location: pages/Employe/dashboard_employe.php");
        } else {
            // Redirection par défaut si le rôle n'est ni Admin ni employe
            header("Location: pages/index.php");
        }
        exit;
    } else {
        $error = "Nom d'utilisateur ou mot de passe incorrect.";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="icon" href="images/Logo.png" type="image/x-icon">
    <title>Connexion</title>
</head>

<body>

    <div class="login-container">
        <?php if (!empty($success_message)): ?>
            <p class="success" id="successMessage">
                <i class="fas fa-check-circle"></i> <!-- Icône de succès -->
                <?= $success_message ?>
            </p>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <p class="error">
                <i class="fas fa-exclamation-circle"></i> <!-- Icône d'erreur -->
                <?= $error ?>
            </p>
        <?php endif; ?>
        <div class="logo-container">
            <div class="logo">
                <img src="images/Logo.png" alt="">
            </div>

        </div>
        <h2>Connexion</h2>
        <form action="index.php" method="post">
            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="text" id="username" name="username" placeholder="Nom d'utilisateur" required>
            </div>

            <div class="input-group">
                <i class="fas fa-lock"></i>
                <input type="password" id="password" name="password" placeholder="Mot de passe" required>
            </div>

            <button type="submit">Se connecter</button>
        </form>
    
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var successMessage = document.getElementById('successMessage');
            if (successMessage) {
                successMessage.style.display = 'block';
                setTimeout(function() {
                    successMessage.style.display = 'none';
                }, 5000); // 5 secondes
            }
        });
    </script>
</body>

</html>