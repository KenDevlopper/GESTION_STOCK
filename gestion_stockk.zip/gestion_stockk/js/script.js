// JavaScript pour gérer les sous-menus et la barre latérale
const menuToggles = document.querySelectorAll(".menu-toggle");
menuToggles.forEach((toggle) => {
  toggle.addEventListener("click", function () {
    const subMenu = this.nextElementSibling;
    const icon = this.querySelector(".accordion-icon");
    if (subMenu.classList.contains("sub-menu-open")) {
      subMenu.classList.remove("sub-menu-open");
      icon.classList.remove("rotate");
    } else {
      document
        .querySelectorAll(".sub-menu")
        .forEach((menu) => menu.classList.remove("sub-menu-open"));
      document
        .querySelectorAll(".accordion-icon")
        .forEach((ic) => ic.classList.remove("rotate"));
      subMenu.classList.add("sub-menu-open");
      icon.classList.add("rotate");
    }
  });
});

const hamburgerMenu = document.querySelector(".hamburger-menu");
const sidebar = document.querySelector(".sidebar");
hamburgerMenu.addEventListener("click", function () {
  sidebar.classList.toggle("sidebar-open");
});

// Afficher le message de succès pendant 3 millisecondes
document.addEventListener("DOMContentLoaded", function () {
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.has("success")) {
    const successMessage = document.getElementById("success-message");
    if (successMessage) {
      let message = "";
      if (urlParams.get("success") === "true") {
        message = "Produit mis à jour avec succès !";
      } else if (urlParams.get("success") === "delete") {
        message = "Produit supprimé avec succès !";
      }
      successMessage.innerHTML =
        '<i class="fas fa-check-circle"></i> ' + message;
      successMessage.style.display = "block";
      setTimeout(function () {
        successMessage.style.display = "none";
      }, 3000); // 3 secondes
    }
  }
});


