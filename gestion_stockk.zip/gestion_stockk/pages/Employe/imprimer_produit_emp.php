<?php
session_start();
require_once '../../config/database.php';
// Vérifier si l'utilisateur est connecté et est un emp
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'employe') {
  header('Location: ../../index.php');
  exit();
}


// Vérifier si un ID de produit a été fourni
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
  die("ID de produit non valide");
}

$id_produit = intval($_GET['id']);

// Récupérer les détails du produit
$sql = "SELECT * FROM produit_impression WHERE id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_produit);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
  die("Produit non trouvé");
}

$produit = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Impression du Produit #<?php echo $produit['id']; ?></title>
  <link rel="icon" href="../../images/Logo.png" type="image/x-icon">
  <style>
    body {
      font-family: 'Helvetica Neue', Arial, sans-serif;
      line-height: 1.6;
      margin: 0;
      padding: 40px;
      color: #333;
    }

    .container {
      max-width: 800px;
      margin: 0 auto;
      border: 1px solid #ddd;
      padding: 30px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 30px;
      border-bottom: 2px solid #3498db;
      padding-bottom: 10px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 30px;
    }

    th,
    td {
      border: 1px solid #ddd;
      padding: 12px;
      text-align: left;
    }

    th {
      background-color: #f8f9fa;
      font-weight: bold;
      color: #2c3e50;
    }

    tr:nth-child(even) {
      background-color: #f8f9fa;
    }

    .footer {
      text-align: center;
      margin-top: 30px;
      font-size: 0.9em;
      color: #7f8c8d;
      border-top: 1px solid #ddd;
      padding-top: 20px;
    }

    .btn {
      display: inline-block;
      padding: 10px 20px;
      background-color: #3498db;
      color: white;
      text-decoration: none;
      border-radius: 5px;
      border: none;
      transition: background-color 0.3s;
    }

    .btnFermer {
      background-color: #dc3545;
    }

    .btn:hover {
      opacity: 0.8;
    }

    @media print {
      .no-print {
        display: none;
      }

      body {
        padding: 0;
      }

      .container {
        border: none;
        box-shadow: none;
      }
    }

    .header {
      text-align: center;
      margin-bottom: 30px;
    }

    .logo {
      max-width: 200px;
      margin-bottom: 10px;
    }

    .company-address {
      font-style: italic;
      color: #555;
    }
  </style>
</head>

<body>
  <div class="container">
    <div class="header">
      <img src="../../images/Logo.png" alt="Logo de l'entreprise" class="logo">

      <p class="company-address">
        <span style="font-weight: bold;">LA SUPRISE C&S MULTI-SERVICE</span>
        <br>
        Adresse: #13, Charrier Av. des Cajoux, Cap-Haïtien<br>
        Téléphone: (+509) 36319633 / 42224449 / 38311304<br>
        Email: pierreviala85@gmail.com
      </p>
    </div>
    <h1>Facture</h1>

    <table>
      <tr>
        <th>Nom du Produit</th>
        <td><?php echo htmlspecialchars($produit['nom_client']); ?></td>
      </tr>
      <tr>
        <th>Produit</th>
        <td><?php echo htmlspecialchars($produit['type_produit']); ?></td>
      </tr>
      <tr>
        <th>Quantite</th>
        <td><?php echo htmlspecialchars($produit['quantite']); ?></td>
      </tr>
      <tr>
        <th>Prix unitaire</th>
        <td><?php echo htmlspecialchars($produit['prix']) . " HTG"; ?></td>
      </tr>
      <tr>
        <th>Prix total</th>
        <td><?php echo htmlspecialchars($produit['prix_total'] . " HTG"); ?></td>
      </tr>
      <tr>
        <th>Date de vente</th>
        <td><?php echo date('d-m-Y', strtotime($produit['date_vente'])); ?></td>
      </tr>
    </table>

    <div class="footer">
      Ce document a été généré le <?php echo date('d-m-Y à H:i:s'); ?>
    </div>

    <div class="no-print" style="text-align: center; margin-top: 20px;">
      <button class="btn" onclick="window.print()">Imprimer</button>
      <button class="btn btnFermer" onclick="window.close()">Fermer</button>
    </div>
  </div>

  <script>
    // Déclencher automatiquement l'impression
    window.onload = function() {
      window.print();
    }
  </script>
</body>

</html>

<?php
$stmt->close();
$conn->close();
?>