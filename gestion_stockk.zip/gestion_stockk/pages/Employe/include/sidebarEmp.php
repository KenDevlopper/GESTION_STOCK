<nav class="sidebar">
  <div class="sidebar-header">
    <i class="fas fa-user-circle" style="font-size: 3rem; margin-bottom: 10px"></i>
    <?php
    if (isset($_SESSION['nom_utilisateur'])) {
      echo "<h4>Bienvenue, " . htmlspecialchars($_SESSION['nom_utilisateur']) . "</h4>";
    } else {
      echo "<p>Utilisateur non connecté</p>";
    }
    ?>
  </div>
  <div class="diviseur"></div>
  <ul class="nav-links">

    <?php
    // Vérification pour les pages de gestion des produits
    $active_ventes = (basename($_SERVER['PHP_SELF']) == 'dashboard_employe.php' ||
      basename($_SERVER['PHP_SELF']) == 'vente_eau_emp.php' ||
      basename($_SERVER['PHP_SELF']) == 'lister_vente_emp.php');
    ?>
    <li>
      <a href="#" class="menu-toggle <?php echo $active_ventes ? 'active' : ''; ?>">
        <i class="fas fa-box"></i> Gestion des Produits
        <i class="fas fa-chevron-down accordion-icon"></i>
      </a>
      <ul class="sub-menu">
        <li><a href="dashboard_employe.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'dashboard_employe.php') ? 'active' : ''; ?>">Vente Produits </a></li>
        <li><a href="vente_eau_emp.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'vente_eau_emp.php') ? 'active' : ''; ?>">Vente sachet d'eau </a></li>
        <li><a href="lister_vente_emp.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'lister_vente_emp.php') ? 'active' : ''; ?>">Liste des ventes </a></li>
      </ul>
    </li>

    <?php
    // Vérification pour les pages de gestion des produits
    $active_recharge = (basename($_SERVER['PHP_SELF']) == 'service_recharge_emp.php' ||
      basename($_SERVER['PHP_SELF']) == 'lister_recharge_emp.php');
    ?>

    <li>
      <a href="#" class="menu-toggle <?php echo $active_recharge ? 'active' : ''; ?>">
        <i class="fas fa-plug"></i> Service recharge
        <i class="fas fa-chevron-down accordion-icon"></i>
      </a>
      <ul class="sub-menu">
        <li><a href="service_recharge_emp.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'service_recharge_emp.php') ? 'active' : ''; ?>">&#9900 Service recharge</a></li>
        <li><a href="lister_recharge_emp.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'lister_recharge_emp.php') ? 'active' : ''; ?>">&#9900 Lister recharge</a></li>

      </ul>
    </li>

    <?php
    // Vérification pour la gestion des impressions
    $active_impression = (basename($_SERVER['PHP_SELF']) == 'service_impression_emp.php' ||
      basename($_SERVER['PHP_SELF']) == 'listes_service_impression_emp.php' ||
      basename($_SERVER['PHP_SELF']) == 'produit_impression_emp.php' ||
      basename($_SERVER['PHP_SELF']) == 'liste_ventesP_emp.php');
    ?>

    <li>
      <a href="#" class="menu-toggle <?php echo $active_impression ? 'active' : ''; ?>">
        <i class="fas fa-print"></i> Gestion Imprimerie
        <i class="fas fa-chevron-down accordion-icon"></i>
      </a>
      <ul class="sub-menu">
        <li><a href="service_impression_emp.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'service_impression_emp.php') ? 'active' : ''; ?>">&#9900 Service Impression</a></li>
        <li><a href="listes_service_impression_emp.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'listes_service_impression_emp.php') ? 'active' : ''; ?>">&#9900 Listes Service</a></li>
        <li><a href="produit_impression_emp.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'produit_impression_emp.php') ? 'active' : ''; ?>">&#9900 Ventes Produits Imp</a></li>
        <li><a href="liste_ventesP_emp.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'liste_ventesP_emp.php') ? 'active' : ''; ?>">&#9900 Listes ventes P. Imp </a></li>


      </ul>
    </li>



  </ul>
  </li>

  </ul>
</nav>