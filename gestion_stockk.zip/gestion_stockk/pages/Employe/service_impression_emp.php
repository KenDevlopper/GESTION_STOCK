<?php
session_start();

// Vérifier si l'utilisateur est connecté et est un emp
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'employe') {
  header('Location: ../../index.php');
  exit();
}

require_once '../../config/database.php';

// Traitement du formulaire lors de la soumission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $type = $_POST['type'];
  $nomClient = $_POST['nomClient'];
  $taille = $_POST['taille'];
  $typePapier = $_POST['typePapier'];
  $categorie = $_POST['categorie'];
  $quantite = $_POST['quantite'];
  $prix = $_POST['prix'];
  $date_impression = date('Y-m-d H:i:s');
  $nom_utilisateur = $_SESSION['nom_utilisateur']; // Récupération du nom d'utilisateur de la session

  $sql = "INSERT INTO service_impression (type, nom_client, taille, type_papier, categorie, quantite, prix,date_impression, nom_utilisateur) VALUES (?,?, ?, ?, ?, ?, ?, ?, ?)";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("sssssidss", $type, $nomClient, $taille, $typePapier, $categorie, $quantite, $prix, $date_impression, $nom_utilisateur);

  if ($stmt->execute()) {
    $_SESSION['message'] = ['type' => 'success', 'text' => 'Service d\'impression enregistré avec succès.'];
  } else {
    $_SESSION['message'] = ['type' => 'error', 'text' => 'Erreur lors de l\'enregistrement du service d\'impression.'];
  }

  header('Location: ' . $_SERVER['PHP_SELF']);
  exit();
}

// Fonction pour récupérer le prix
function getPrix($conn, $type, $taille, $typePapier, $categorie)
{
  $sql = "SELECT prix FROM imprimerie WHERE type = ? AND taille = ? AND type_papier = ? AND categorie = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("ssss", $type, $taille, $typePapier, $categorie);
  $stmt->execute();
  $result = $stmt->get_result();
  if ($row = $result->fetch_assoc()) {
    return $row['prix'];
  }
  return null;
}

// Récupérer les options pour les sélecteurs
function getOptions($conn, $column)
{
  $sql = "SELECT DISTINCT $column FROM imprimerie";
  $result = $conn->query($sql);
  $options = [];
  while ($row = $result->fetch_assoc()) {
    $options[] = $row[$column];
  }
  return $options;
}

$typeOptions = getOptions($conn, 'type');
$tailleOptions = getOptions($conn, 'taille');
$typePapierOptions = getOptions($conn, 'type_papier');
$categorieOptions = getOptions($conn, 'categorie');

?>

<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../../css/impression.css">
  <link rel="stylesheet" href="../../fontawesome/css/all.min.css">
  <link rel="icon" href="../../images/Logo.png" type="image/x-icon">
  <title>Donnee Imprimerie</title>
  <style>
    /* Conteneur pour les messages */
    #alert-container {
      position: fixed;
      top: 10px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 1000;
    }

    /* Style de base pour les messages */
    .alert {
      padding: 15px;
      margin-bottom: 10px;
      border-radius: 5px;
      color: #fff;
      font-size: 16px;
      opacity: 1;
      transition: opacity 0.5s ease;
      display: flex;
      align-items: center;

    }

    /* Style pour les icônes */
    .alert i {
      margin-right: 10px;
      font-size: 20px;
    }

    /* Style pour les messages de succès */
    .alert.success {
      background-color: #28a745;
      border: 1px solid #1e7e34;
    }

    /* Style pour les messages d'erreur */
    .alert.error {
      background-color: #dc3545;
      border: 1px solid #c82333;
    }

    /* Style pour les messages d'information */
    .alert.info {
      background-color: #17a2b8;
      border: 1px solid #117a8b;
    }

    /* Style pour les messages d'avertissement */
    .alert.warning {
      background-color: #ffc107;
      border: 1px solid #e0a800;
    }
  </style>
</head>

<body>
  <header>
    <i class="fas fa-bars hamburger-menu"></i>
    <h3>La Suprise C&S Multi-Service</h3>
    <a href="../../config/logout.php"><i class="fas fa-sign-out-alt"></i></a>
  </header>

  <!-- Div pour le message de succès -->
  <div id="alert-container"></div>

  <div class="dashboard-container">
    <?php include_once 'include/sidebarEmp.php'; ?>
    <div class="main-content">
      <div class="overlay"></div>
      <section class="content">
        <div class="titre">
          <h3>Service Impression</h3>
        </div>
        <form method="POST" action="">
          <div class="form-column">
            <label for="nomClient">Nom Client:</label>
            <input type="text" id="nomClient" name="nomClient" required>

            <label for="type">Type:</label>
            <select name="type" id="type" required>
              <option value="">Choisir...</option>
              <?php foreach ($typeOptions as $option): ?>
                <option value="<?php echo htmlspecialchars($option); ?>"><?php echo htmlspecialchars($option); ?></option>
              <?php endforeach; ?>
            </select>

            <label for="taille">Taille:</label>
            <select name="taille" id="taille" required>
              <option value="">Choisir...</option>

              <?php foreach ($tailleOptions as $option): ?>
                <option value="<?php echo htmlspecialchars($option); ?>"><?php echo htmlspecialchars($option); ?></option>
              <?php endforeach; ?>
            </select>
          </div>




          <div class="form-column">
            <label for="typePapier">Type Papier:</label>
            <select name="typePapier" id="typePapier" required>
              <option value="">Choisir...</option>
              <?php foreach ($typePapierOptions as $option): ?>
                <option value="<?php echo htmlspecialchars($option); ?>"><?php echo htmlspecialchars($option); ?></option>
              <?php endforeach; ?>
            </select>
            <label for="categorie">Categorie:</label>
            <select name="categorie" id="categorie" required>
              <option value="">Choisir...</option>
              <?php foreach ($categorieOptions as $option): ?>
                <option value="<?php echo htmlspecialchars($option); ?>"><?php echo htmlspecialchars($option); ?></option>
              <?php endforeach; ?>
            </select>

            <label for="quantite">Quantite:</label>
            <input type="number" name="quantite" id="quantite" min="1" value="1" required>
          </div>

          <label for="prix">Prix:</label>
          <input type="number" name="prix" id="prix" step="0.01" readonly>

          <!-- Vous pouvez ajouter un quatrième élément ici si nécessaire -->


          <button type="submit">Enregistrer</button>
        </form>
      </section>
      <footer>
        <small>&copy; <?php echo date("Y"); ?>La Suprise C&M Multi-Services. Tous droits réservés.</small>
      </footer>
    </div>
  </div>

  <script src="../../js/script.js"></script>
  <script>
    // Fonction pour afficher le message
    function afficherMessage(type, message) {
      const alertContainer = document.getElementById('alert-container');
      if (!alertContainer) return;

      const alertMessage = document.createElement('div');
      alertMessage.className = `alert ${type}`;

      let icon;
      switch (type) {
        case 'success':
          icon = '<i class="fas fa-check-circle"></i>';
          break;
        case 'error':
          icon = '<i class="fas fa-exclamation-circle"></i>';
          break;
        case 'info':
          icon = '<i class="fas fa-info-circle"></i>';
          break;
        case 'warning':
          icon = '<i class="fas fa-exclamation-triangle"></i>';
          break;
        default:
          icon = '';
      }

      alertMessage.innerHTML = `${icon} ${message}`;
      alertContainer.appendChild(alertMessage);

      setTimeout(() => {
        alertMessage.style.opacity = '0';
        setTimeout(() => alertMessage.remove(), 500);
      }, 3000);
    }
    // Vérifier et afficher le message de session au chargement de la page
    document.addEventListener('DOMContentLoaded', function() {
      <?php
      if (isset($_SESSION['message'])) {
        echo "afficherMessage('" . $_SESSION['message']['type'] . "', '" . addslashes($_SESSION['message']['text']) . "');";
        unset($_SESSION['message']);
      }
      ?>
    });

    // Fonction pour mettre à jour le prix
    function updatePrix() {
      var type = document.getElementById('type').value;
      var taille = document.getElementById('taille').value;
      var typePapier = document.getElementById('typePapier').value;
      var categorie = document.getElementById('categorie').value;
      var quantite = document.getElementById('quantite').value;

      if (type && taille && typePapier && categorie) {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', '../get_prix.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onload = function() {
          if (xhr.status === 200) {
            var prixUnitaire = parseFloat(xhr.responseText);
            if (!isNaN(prixUnitaire)) {
              var prixTotal = prixUnitaire * quantite;
              document.getElementById('prix').value = prixTotal.toFixed(2);
            } else {
              document.getElementById('prix').value = '';
            }
          }
        };
        xhr.send('type=' + encodeURIComponent(type) + '&taille=' + encodeURIComponent(taille) + '&typePapier=' + encodeURIComponent(typePapier) + '&categorie=' + encodeURIComponent(categorie));
      }
    }

    // Fonction pour mettre à jour le prix en fonction de la quantité
    function updatePrixQuantite() {
      var prixUnitaire = parseFloat(document.getElementById('prix').value) / parseFloat(document.getElementById('quantite').value);
      var nouvelleQuantite = parseFloat(document.getElementById('quantite').value);
      if (!isNaN(prixUnitaire) && !isNaN(nouvelleQuantite)) {
        document.getElementById('prix').value = (prixUnitaire * nouvelleQuantite).toFixed(2);
      }
    }

    // Ajouter les écouteurs d'événements
    document.addEventListener('DOMContentLoaded', function() {
      var elements = ['type', 'taille', 'typePapier', 'categorie', 'quantite'];
      elements.forEach(function(id) {
        document.getElementById(id).addEventListener('change', updatePrix);
      });

      // Ajouter un écouteur d'événements spécifique pour la quantité
      // Ajouter un écouteur d'événements spécifique pour la quantité
      document.getElementById('quantite').addEventListener('input', updatePrix);

      <?php
      if (isset($_SESSION['message'])) {
        echo "afficherMessage('" . $_SESSION['message']['type'] . "', '" . addslashes($_SESSION['message']['text']) . "');";
        unset($_SESSION['message']);
      }
      ?>

      // Appeler updatePrix une fois au chargement de la page
      updatePrix();
    });
  </script>

</body>

</html>