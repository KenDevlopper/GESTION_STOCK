<?php
session_start();

// Vérifier si l'utilisateur est connecté et est un administrateur
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
  header('Location: ../index.php');
  exit();
}
require_once '../config/database.php';

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $numeroCarte = $_POST['numeroCarte'];
  $nomClient = $_POST['nomClient'];
  $appareils = $_POST['appareils'];
  $typeRecharge = $_POST['typeRecharge'];
  $quantite = $_POST['quantite'];
  $prix_total = $_POST['prix_total'];
  $date_recharge = date('Y-m-d H:i:s');
  $nom_utilisateur = $_SESSION['nom_utilisateur']; // Récupération du nom d'utilisateur de la session

  // Vérifier si le numéro de carte existe déjà
  $checkSql = "SELECT COUNT(*) FROM service_recharge WHERE numero_carte = ?";
  $checkStmt = $conn->prepare($checkSql);
  $checkStmt->bind_param("s", $numeroCarte);
  $checkStmt->execute();
  $checkStmt->bind_result($count);
  $checkStmt->fetch();
  $checkStmt->close();

  if ($count > 0) {
    $_SESSION['message'] = ['type' => 'error', 'text' => 'Le numéro de carte existe déjà.'];
  } else {
    $sql = "INSERT INTO service_recharge (numero_carte, nomClient, appareil, type_recharge, quantite, prix_total, date_recharge, nom_utilisateur) VALUES (?,?,?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssidss", $numeroCarte, $nomClient, $appareils, $typeRecharge, $quantite, $prix_total, $date_recharge, $nom_utilisateur);

    if ($stmt->execute()) {
      $_SESSION['message'] = ['type' => 'success', 'text' => 'Service recharge enregistrée avec succès!'];
    } else {
      $_SESSION['message'] = ['type' => 'error', 'text' => 'Erreur lors de l\'enregistrement de la recharge.'];
    }

    $stmt->close();
  }

  header('Location: service_recharge.php');
  exit();
}
?>


<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../css/produitImpression.css">
  <link rel="stylesheet" href="../fontawesome/css/all.min.css">
  <link rel="shortcut icon" href="../images/Logo.png" type="image/x-icon">
  <title>Service de recharge</title>
  <style>
    /* Conteneur pour les messages */
    #alert-container {
      position: fixed;
      top: 10px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 1000;
    }

    /* Style de base pour les messages */
    .alert {
      padding: 15px;
      margin-bottom: 10px;
      border-radius: 5px;
      color: #fff;
      font-size: 16px;
      opacity: 1;
      transition: opacity 0.5s ease;
      display: flex;
      align-items: center;

    }

    /* Style pour les icônes */
    .alert i {
      margin-right: 10px;
      font-size: 20px;
    }

    /* Style pour les messages de succès */
    .alert.success {
      background-color: #28a745;
      border: 1px solid #1e7e34;
    }

    /* Style pour les messages d'erreur */
    .alert.error {
      background-color: #dc3545;
      border: 1px solid #c82333;
    }

    /* Style pour les messages d'information */
    .alert.info {
      background-color: #17a2b8;
      border: 1px solid #117a8b;
    }

    /* Style pour les messages d'avertissement */
    .alert.warning {
      background-color: #ffc107;
      border: 1px solid #e0a800;
    }
  </style>
</head>

<body>
  <header>
    <i class="fas fa-bars hamburger-menu"></i>
    <h3>Suprise C&S Multi-Service</h3>
    <a href="../config/logout.php"><i class="fas fa-sign-out-alt"></i></a>
  </header>

  <!-- Div pour le message de succès -->
  <div id="alert-container"></div>

  <div class="dashboard-container">
    <?php include_once '../includes/sidebar.php'; ?>
    <div class="main-content">
      <div class="overlay"></div>
      <section class="content">
        <div class="titre">
          <h3>Service de recharge</h3>
        </div>
        <form method="POST" action="">
          <label for="numeroCarte">Numéro de carte:</label>
          <input type="number" id="numeroCarte" name="numeroCarte" required>
          
          <label for="nomClient">Nom Client:<label>
          <input type="text" id= "nomClient" name= "nomClient" required>
          
          <label for="appareils">Appareils:</label>
          <select name="appareils" id="appareils" required>
            <option value="">Choisir...</option>
            <option value="Telephone">Téléphone</option>
            <option value="Tablet">Tablet</option>
            <option value="Laptop">Laptop</option>
            <option value="Radio">Radio</option>
            <option value="Ventilateur">Ventilateur</option>
            <option value="Ampoule">Ampoule</option>
          </select>

          <label for="typeRecharge">Type de Recharge</label>
          <select name="typeRecharge" id="typeRecharge" required>
            <option value="">Choisir...</option>
            <option value="Avec chargeur">Avec chargeur</option>
            <option value="Sans chargeur">Sans chargeur</option>
          </select>

          <label for="quantite">Quantité:</label>
          <input type="number" id="quantite" min="1" name="quantite" required>

          <label for="prix_total">Prix total:</label>
          <input type="number" id="prix_total" name="prix_total" step="0.01" required>

          <button type="submit">Paiement</button>
        </form>
      </section>
      <footer>
        <small>&copy; <?php echo date("Y"); ?> La Suprise C&S Multi-Services. Tous droits réservés.</small>
      </footer>
    </div>
  </div>

  <script src="../js/script.js"></script>
  <script>
    // Fonction pour afficher le message
    function afficherMessage(type, message) {
      const alertContainer = document.getElementById('alert-container');
      if (!alertContainer) return;

      const alertMessage = document.createElement('div');
      alertMessage.className = `alert ${type}`;

      let icon;
      switch (type) {
        case 'success':
          icon = '<i class="fas fa-check-circle"></i>';
          break;
        case 'error':
          icon = '<i class="fas fa-exclamation-circle"></i>';
          break;
        case 'info':
          icon = '<i class="fas fa-info-circle"></i>';
          break;
        case 'warning':
          icon = '<i class="fas fa-exclamation-triangle"></i>';
          break;
        default:
          icon = '';
      }

      alertMessage.innerHTML = `${icon} ${message}`;
      alertContainer.appendChild(alertMessage);

      setTimeout(() => {
        alertMessage.style.opacity = '0';
        setTimeout(() => alertMessage.remove(), 500);
      }, 3000);
    }
    // Vérifier et afficher le message de session au chargement de la page
    document.addEventListener('DOMContentLoaded', function() {
      <?php
      if (isset($_SESSION['message'])) {
        echo "afficherMessage('" . $_SESSION['message']['type'] . "', '" . addslashes($_SESSION['message']['text']) . "');";
        unset($_SESSION['message']);
      }
      ?>
    });



    <?php
    if (isset($_SESSION['message'])) {
      echo "afficherMessage('" . $_SESSION['message']['type'] . "', '" . addslashes($_SESSION['message']['text']) . "');";
      unset($_SESSION['message']);
    }
    ?>
  </script>

</body>

</html>