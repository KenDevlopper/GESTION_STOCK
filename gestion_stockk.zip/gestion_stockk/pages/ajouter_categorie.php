<?php
session_start();

// Vérifier si l'utilisateur est connecté et est un administrateur
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../index.php');
    exit();
}
require_once '../config/database.php';

// Ajouter une catégorie
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nom_categorie'])) {
    $nom_categorie = trim($_POST['nom_categorie']);

    if (!empty($nom_categorie)) {
        // Vérifier si la catégorie existe déjà
        $stmt_check = $conn->prepare("SELECT COUNT(*) FROM categories WHERE nom_categorie = ?");
        $stmt_check->bind_param("s", $nom_categorie);
        $stmt_check->execute();
        $stmt_check->bind_result($count);
        $stmt_check->fetch();
        $stmt_check->close();

        if ($count > 0) {
            $_SESSION['message'] = ['type' => 'warning', 'text' => 'Cette catégorie existe déjà'];
        } else {
            // Préparer la requête d'insertion
            $stmt = $conn->prepare("INSERT INTO categories (nom_categorie) VALUES (?)");
            $stmt->bind_param("s", $nom_categorie);

            if ($stmt->execute()) {
                $_SESSION['message'] = ['type' => 'success', 'text' => 'Catégorie ajoutée avec succès'];
                header('Location: ajouter_categorie.php');
                exit();
            } else {
                $_SESSION['message'] = ['type' => 'error', 'text' => 'Erreur lors de l\'ajout de la catégorie'];
            }

            $stmt->close();
        }
    } else {
        $_SESSION['message'] = ['type' => 'warning', 'text' => 'Le nom de la catégorie ne peut pas être vide'];
    }
}
//Supprimer une catégorie
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $stmt = $conn->prepare("DELETE FROM categories WHERE id = ?");
    $stmt->bind_param("i", $delete_id);

    if ($stmt->execute()) {
        $_SESSION['message'] = ['type' => 'success', 'text' => 'Catégorie supprimée avec succès'];
    } else {
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Erreur lors de la suppression de la catégorie'];
    }

    $stmt->close();
    header('Location: ajouter_categorie.php');
    exit();
}


// Récupérer toutes les catégories
$categories_result = $conn->query("SELECT * FROM categories ORDER BY id ASC");
?>



<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/ajouterCategorie.css">
    <link rel="stylesheet" href="../fontawesome/css/all.min.css">
    <link rel="shortcut icon" href="../images/Logo.png" type="image/x-icon">
    <title>Ajouter Catégorie</title>
    <style>
        /* Conteneur pour les messages */
        #alert-container {
            position: fixed;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 1002;
        }

        /* Style de base pour les messages */
        .alert {
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 5px;
            color: #fff;
            font-size: 16px;
            opacity: 1;
            transition: opacity 0.5s ease;
            display: flex;
            align-items: center;

        }

        /* Style pour les icônes */
        .alert i {
            margin-right: 10px;
            font-size: 20px;
        }

        /* Style pour les messages de succès */
        .alert.success {
            background-color: #28a745;
            border: 1px solid #1e7e34;
        }

        /* Style pour les messages d'erreur */
        .alert.error {
            background-color: #dc3545;
            border: 1px solid #c82333;
        }

        /* Style pour les messages d'information */
        .alert.info {
            background-color: #17a2b8;
            border: 1px solid #117a8b;
        }

        /* Style pour les messages d'avertissement */
        .alert.warning {
            background-color: #ffc107;
            border: 1px solid #e0a800;
        }
    </style>
</head>

<body>
    <header>
        <i class="fas fa-bars hamburger-menu"></i>
        <h3>La Suprise C&S Multi-Service</h3>
        <a href="../config/logout.php"><i class="fas fa-sign-out-alt"></i></a>
    </header>

    <!-- Div pour le message de succès -->
    <div id="alert-container"></div>

    <div class="dashboard-container">
        <?php include_once '../includes/sidebar.php'; ?>

        <div class="main-content">
            <div class="overlay"></div>
            <section class="content">
                <form method="POST" action="">
                    <label for="nom_categorie">catégorie:</label>
                    <input type="text" name="nom_categorie" id="nom_categorie" placeholder="Saisir une categorie" required>
                    <button type="submit">Enregistrer</button>
                </form>

                <hr>

                <div class="table-container">
                    <table class="styled-table">
                        <thead>
                            <div class="tabHead">
                                <h3>Liste des catégories</h3>
                            </div>
                            <tr>
                                <th>ID</th>
                                <th>Nom de la Catégorie</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($categories_result->num_rows > 0) {
                                while ($row = $categories_result->fetch_assoc()) {
                                    echo "<tr>";
                                    echo "<td>" . $row['id'] . "</td>";
                                    echo "<td>" . htmlspecialchars($row['nom_categorie']) . "</td>";
                                    echo "<td>";
                                    echo "<button class='btnSup'><a href='?delete_id=" . $row['id'] . "'><i class='fas fa-trash-alt'></i> Supprimer</a></button>";
                                    echo "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='3'>Aucune catégorie trouvée.</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </section>
            <footer>
                <small>&copy; <?php echo date("Y"); ?>La Suprise C&M Multi-Services. Tous droits réservés.</small>
            </footer>
        </div>
    </div>

    <script src="../js/script.js"> </script>
    <script>
        // Fonction pour afficher le message
        function afficherMessage(type, message) {
            const alertContainer = document.getElementById('alert-container');
            if (!alertContainer) return;

            const alertMessage = document.createElement('div');
            alertMessage.className = `alert ${type}`;

            let icon;
            switch (type) {
                case 'success':
                    icon = '<i class="fas fa-check-circle"></i>';
                    break;
                case 'error':
                    icon = '<i class="fas fa-exclamation-circle"></i>';
                    break;
                case 'info':
                    icon = '<i class="fas fa-info-circle"></i>';
                    break;
                case 'warning':
                    icon = '<i class="fas fa-exclamation-triangle"></i>';
                    break;
                default:
                    icon = '';
            }

            alertMessage.innerHTML = `${icon} ${message}`;
            alertContainer.appendChild(alertMessage);

            setTimeout(() => {
                alertMessage.style.opacity = '0';
                setTimeout(() => alertMessage.remove(), 500);
            }, 3000);
        }
        // Vérifier et afficher le message de session au chargement de la page
        document.addEventListener('DOMContentLoaded', function() {
            <?php
            if (isset($_SESSION['message'])) {
                echo "afficherMessage('" . $_SESSION['message']['type'] . "', '" . addslashes($_SESSION['message']['text']) . "');";
                unset($_SESSION['message']);
            }
            ?>
        });
    </script>

</body>

</html>