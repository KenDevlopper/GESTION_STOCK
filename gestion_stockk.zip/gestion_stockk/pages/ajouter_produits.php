<?php
session_start();

// Vérifier si l'utilisateur est connecté et est un administrateur
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../index.php');
    exit();
}


require_once '../config/database.php';

// Récupérer les catégories pour le dropdown
$categories_result = $conn->query("SELECT id, nom_categorie FROM categories ORDER BY nom_categorie ASC");

// Ajouter un produit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nom_produit'], $_POST['description'], $_POST['prix_unite'], $_POST['caisse'], $_POST['unite'], $_POST['prix_caisse'], $_POST['id_categorie'])) {
    $nom_produit = trim($_POST['nom_produit']);
    $description = trim($_POST['description']);
    $prix_unite = floatval($_POST['prix_unite']);
    $caisse = intval($_POST['caisse']);
    $unite = intval($_POST['unite']);
    $prix_caisse = floatval($_POST['prix_caisse']);
    $id_categorie = intval($_POST['id_categorie']);

    // Calcul de la quantité (nombre de caisses * 24)
    $quantite_produit = $unite+($caisse * 24);

    if (!empty($nom_produit) && $prix_unite > 0 && $caisse > 0 && $id_categorie > 0) {
        // Préparer la requête d'insertion avec NOW() pour la date d'enregistrement
        $stmt = $conn->prepare("INSERT INTO produits (nom_produit, description, prix_unite, caisse, unite, prix_caisse, quantite_produit, id_categorie, date_enregistrement) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
        $stmt->bind_param("ssdsssii", $nom_produit, $description, $prix_unite, $caisse, $unite, $prix_caisse, $quantite_produit, $id_categorie);

        if ($stmt->execute()) {
            $_SESSION['message'] = ['type' => 'success', 'text' => 'Produit ajouté avec succès'];
            // Rediriger pour éviter la soumission répétée
            header('Location: ajouter_produits.php');
            exit();
        } else {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Erreur lors de l\'ajout de la catégorie'];
        }

        $stmt->close();
    }
}
?>



<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/ajouterProduit.css">
    <link rel="stylesheet" href="../fontawesome/css/all.min.css">
    <link rel="shortcut icon" href="../images/Logo.png" type="image/x-icon">
    <title>Ajouter Produits</title>
    <style>
        /* Conteneur pour les messages */
        #alert-container {
            position: fixed;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 1002;
        }

        /* Style de base pour les messages */
        .alert {
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 5px;
            color: #fff;
            font-size: 16px;
            opacity: 1;
            transition: opacity 0.5s ease;
            display: flex;
            align-items: center;
            /* Alignement des icônes et du texte */
        }

        /* Style pour les icônes */
        .alert i {
            margin-right: 10px;
            /* Espacement entre l'icône et le texte */
            font-size: 20px;
            /* Taille de l'icône */
        }

        /* Style pour les messages de succès */
        .alert.success {
            background-color: #28a745;
            /* Couleur verte pour le succès */
            border: 1px solid #1e7e34;
            /* Couleur plus foncée pour le bord */
        }

        /* Style pour les messages d'erreur */
        .alert.error {
            background-color: #dc3545;
            /* Couleur rouge pour l'erreur */
            border: 1px solid #c82333;
            /* Couleur plus foncée pour le bord */
        }

        /* Style pour les messages d'information */
        .alert.info {
            background-color: #17a2b8;
            /* Couleur bleue pour l'information */
            border: 1px solid #117a8b;
            /* Couleur plus foncée pour le bord */
        }

        /* Style pour les messages d'avertissement */
        .alert.warning {
            background-color: #ffc107;
            /* Couleur jaune pour l'avertissement */
            border: 1px solid #e0a800;
            /* Couleur plus foncée pour le bord */
        }
    </style>

</head>

<body>
    <header>
        <i class="fas fa-bars hamburger-menu"></i>
        <h3>La Suprise C&S Multi-Service</h3>
        <a href="../config/logout.php"><i class="fas fa-sign-out-alt"></i></a>
    </header>

    <!-- Div pour le message de succès -->
    <div id="alert-container"></div>

    <div class="dashboard-container">
        <?php include_once '../includes/sidebar.php'; ?>
        <div class="main-content">
            <div class="overlay"></div>
            <section class="content">
                <div class="titre">
                    <h3>ENREGISTREMENT PRODUIT</h3>
                </div>


                <form method="POST" action="">
                    <div class="form-row">
                        <div class="form-colonne">
                            <label for="nom_produit">Nom du produit:</label>
                            <input type="text" name="nom_produit" id="nom_produit" placeholder="Nom du produit" required>

                            <label for="description">Description:</label>
                            <textarea name="description" id="description" placeholder="Description du produit"></textarea>

                            <label for="prix">Prix unitaire:</label>
                            <input type="number" name="prix_unite" id="prix_unite" placeholder="Prix du produit" step="0.01" required>
                        </div>

                        <div class="form-colonne">
                            <label for="caisse">Caisse:</label>
                            <input type="number" name="caisse" id="caisse" placeholder="Nombre de caisse" required>
                            <label for="unite">Unité:</label>
                            <input type="number" name="unite" id="unite" placeholder="Nombre d'unité" required>
                            <label for="caisse">Prix / Caisse:</label>
                            <input type="number" name="prix_caisse" id="prix_caisse" placeholder="prix par caisse" required>
                            <label for="id_categorie">Catégorie:</label>
                            <select name="id_categorie" id="id_categorie" required>
                                <option value="">Sélectionner une catégorie</option>
                                <?php
                                if ($categories_result->num_rows > 0) {
                                    while ($row = $categories_result->fetch_assoc()) {
                                        echo "<option value='" . $row['id'] . "'>" . htmlspecialchars($row['nom_categorie']) . "</option>";
                                    }
                                }
                                ?>
                            </select>
                        </div>


                    </div>
                    <button type="submit">Enregistrer</button>
                </form>



            </section>
            <footer>
                <small>&copy; <?php echo date("Y"); ?>La Suprise C&S Multi-Services. Tous droits réservés.</small>
            </footer>
        </div>
    </div>

    <script src="../js/script.js"></script>
    <script>
        // Fonction pour afficher le message
        function afficherMessage(type, message) {
            const alertContainer = document.getElementById('alert-container');
            if (!alertContainer) return;

            const alertMessage = document.createElement('div');
            alertMessage.className = `alert ${type}`;

            let icon;
            switch (type) {
                case 'success':
                    icon = '<i class="fas fa-check-circle"></i>';
                    break;
                case 'error':
                    icon = '<i class="fas fa-exclamation-circle"></i>';
                    break;
                case 'info':
                    icon = '<i class="fas fa-info-circle"></i>';
                    break;
                case 'warning':
                    icon = '<i class="fas fa-exclamation-triangle"></i>';
                    break;
                default:
                    icon = '';
            }

            alertMessage.innerHTML = `${icon} ${message}`;
            alertContainer.appendChild(alertMessage);

            setTimeout(() => {
                alertMessage.style.opacity = '0';
                setTimeout(() => alertMessage.remove(), 500);
            }, 3000);
        }
        // Vérifier et afficher le message de session au chargement de la page
        document.addEventListener('DOMContentLoaded', function() {
            <?php
            if (isset($_SESSION['message'])) {
                echo "afficherMessage('" . $_SESSION['message']['type'] . "', '" . addslashes($_SESSION['message']['text']) . "');";
                unset($_SESSION['message']);
            }
            ?>
        });
    </script>

</body>

</html>