<?php
session_start();
// Inclure la connexion à la base de données
require_once '../config/database.php';

// Vérifier si l'utilisateur est connecté et est un administrateur
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
  header('Location: ../index.php');
  exit();
}


$search = '';
$results = [];

// Vérifier si le paramètre 'search' est présent dans l'URL
if (isset($_GET['search']) && !empty($_GET['search'])) {
  $search = htmlspecialchars($_GET['search']);  // Sécuriser l'entrée utilisateur

  // Requête SQL pour rechercher des produits qui correspondent au mot-clé
  $stmt = $conn->prepare("SELECT * FROM produits WHERE nom_produit LIKE ?");
  $searchParam = '%' . $search . '%';
  $stmt->bind_param('s', $searchParam);
  $stmt->execute();
  $result = $stmt->get_result();

  // Stocker les résultats dans un tableau
  while ($row = $result->fetch_assoc()) {
    $results[] = $row;
  }
  $stmt->close();
}

?>

<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../css/ajouterVente.css">
  <link rel="stylesheet" href="../fontawesome/css/all.min.css">
  <link rel="shortcut icon" href="../images/Logo.png" type="image/x-icon">
  <title>Gestion de vente</title>
  <style>
    /* Conteneur pour les messages */
    #alert-container {
      position: fixed;
      top: 10px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 1000;
    }

    /* Style de base pour les messages */
    .alert {
      padding: 15px;
      margin-bottom: 10px;
      border-radius: 5px;
      color: #fff;
      font-size: 16px;
      opacity: 1;
      transition: opacity 0.5s ease;
      display: flex;
      align-items: center;
      /* Alignement des icônes et du texte */
    }

    /* Style pour les icônes */
    .alert i {
      margin-right: 10px;
      /* Espacement entre l'icône et le texte */
      font-size: 20px;
      /* Taille de l'icône */
    }

    /* Style pour les messages de succès */
    .alert.success {
      background-color: #28a745;
      /* Couleur verte pour le succès */
      border: 1px solid #1e7e34;
      /* Couleur plus foncée pour le bord */
    }

    /* Style pour les messages d'erreur */
    .alert.error {
      background-color: #dc3545;
      /* Couleur rouge pour l'erreur */
      border: 1px solid #c82333;
      /* Couleur plus foncée pour le bord */
    }

    /* Style pour les messages d'information */
    .alert.info {
      background-color: #17a2b8;
      /* Couleur bleue pour l'information */
      border: 1px solid #117a8b;
      /* Couleur plus foncée pour le bord */
    }

    /* Style pour les messages d'avertissement */
    .alert.warning {
      background-color: #ffc107;
      /* Couleur jaune pour l'avertissement */
      border: 1px solid #e0a800;
      /* Couleur plus foncée pour le bord */
    }
  </style>
</head>

<body>
  <header>
    <i class="fas fa-bars hamburger-menu"></i>
    <h3>La Suprise C&S Multi-Service</h3>
    <a href="../config/logout.php"><i class="fas fa-sign-out-alt"></i></a>
  </header>

  <!-- Div pour le message de succès -->
  <div id="alert-container"></div>


  <div class="dashboard-container">
    <?php include_once '../includes/sidebar.php'; ?>

    <div class="main-content">
      <div class="overlay"></div>
      <section class="content">
        <div class="vente_container">
          <div class="rechercher">
            <!-- Formulaire de recherche -->
            <form>
              <input type="text" id="search" name="search" placeholder="Rechercher un produit..." autocomplete="off">
              <div id="suggestions"></div>
            </form>
          </div>

          <div class="table_vente" id="table_vente"></div>

        </div>
        <div class="facture">
          <div class="detail_fact">
            <h3>Facture</h3>
            <hr>
            <p>Date: <span id="facture_date"></span></p>
            <p>Client: <span id="facture_nom_client"></span></p>
            <p>Nom Produit: <span id="facture_nom_produit"></span></p>
            <p>Type: <span id="facture_type"></span></p>
            <p>Quantité: <span id="facture_quantite"></span></p>
            <p>Montant: <span id="facture_montant"></span></p>
          </div>

          <div class="paiement">
            <label for="nom_client">Nom du client:</label>
            <input type="text" id="nom_client" oninput="updateFactureNomClient()">
            <label for="">Montant reçu:</label>
            <input type="text" id="montant_recu" oninput="calculerMontantRendre()">
            <label for="">Montant à rendre:</label>
            <input type="text" id="montant_rendre" readonly>
            <label for="">Balance:</label>
            <input type="text" id="balance" readonly>
            <div class="btnPaiement">
              <button type="button" class="btn_paiement" onclick="enregistrerVente()"><i class="fas fa-money-bill-wave"></i> Paiement</button>
              <button type="button" class="btn_annuler" onclick="annulerPaiement()"><i class="fas fa-times"> </i> Annuler Paiement</button>
            </div>
            </input>
          </div>


      </section>
      <footer>
        <small>&copy; <?php echo date("Y"); ?>La Suprise C&S Multi-Services. Tous droits réservés.</small>
      </footer>
    </div>
  </div>

  <script>
    // JavaScript pour gérer les sous-menus et la barre latérale
    const menuToggles = document.querySelectorAll('.menu-toggle');
    menuToggles.forEach(toggle => {
      toggle.addEventListener('click', function() {
        const subMenu = this.nextElementSibling;
        const icon = this.querySelector('.accordion-icon');
        if (subMenu.classList.contains('sub-menu-open')) {
          subMenu.classList.remove('sub-menu-open');
          icon.classList.remove('rotate');
        } else {
          document.querySelectorAll('.sub-menu').forEach(menu => menu.classList.remove('sub-menu-open'));
          document.querySelectorAll('.accordion-icon').forEach(ic => ic.classList.remove('rotate'));
          subMenu.classList.add('sub-menu-open');
          icon.classList.add('rotate');
        }
      });
    });

    const hamburgerMenu = document.querySelector('.hamburger-menu');
    const sidebar = document.querySelector('.sidebar');
    hamburgerMenu.addEventListener('click', function() {
      sidebar.classList.toggle('sidebar-open');
    });


    document.addEventListener('DOMContentLoaded', function() {
      // Vérifier si le message est présent et le masquer après 3 secondes
      const alertMessage = document.getElementById('alert-message');
      if (alertMessage) {
        setTimeout(() => {
          alertMessage.style.opacity = '0'; // Disparaître progressivement
          setTimeout(() => {
            alertMessage.style.display = 'none'; // Masquer complètement
          }, 500); // Attendre la transition (0.5s) avant de masquer
        }, 3000); // 3 secondes avant de commencer à disparaître
      }
    });


    // Fonction de recherche
    function rechercherProduits(search) {
      // Si l'input est vide, on cache les suggestions et on vide le tableau
      if (search === '') {
        document.getElementById('suggestions').style.display = 'none';
        document.getElementById('table_vente').innerHTML = '';
        return;
      }

      // Requête AJAX pour rechercher les produits
      const xhr = new XMLHttpRequest();
      xhr.open('GET', 'search_produits.php?search=' + encodeURIComponent(search), true);
      xhr.onload = function() {
        if (xhr.status === 200) {
          const results = JSON.parse(xhr.responseText);
          let output = '';

          if (results.length > 0) {
            // Générer la liste des suggestions
            results.forEach(function(produit) {
              output += `<div class="suggestion-item" data-id="${produit.id}" data-nom="${produit.nom_produit}" style="padding: 10px; cursor: pointer;">
                       ${produit.nom_produit}
                     </div>`;
            });
          } else {
            output = '<p style="padding: 10px;">Aucun produit trouvé.</p>';
          }

          // Afficher les suggestions sous l'input
          const suggestionsDiv = document.getElementById('suggestions');
          suggestionsDiv.innerHTML = output;
          suggestionsDiv.style.display = 'block';

          // Ajouter un événement pour chaque suggestion
          const suggestionItems = document.querySelectorAll('.suggestion-item');
          suggestionItems.forEach(function(item) {
            item.addEventListener('click', function() {
              const selectedProduct = this.getAttribute('data-nom');
              const productId = this.getAttribute('data-id');

              // Remplir l'input avec le nom du produit sélectionné
              document.getElementById('search').value = selectedProduct;

              // Cacher les suggestions
              document.getElementById('suggestions').style.display = 'none';

              // Requête AJAX pour afficher les détails du produit sélectionné
              displayProductDetails(productId);
            });
          });
        }
      };
      xhr.send();
    }

    // Variables globales pour stocker les informations du produit sélectionné
    let montantTotal = 0;
    let produitId = null;
    let typeProduit = '';
    let quantiteProduit = 0;

    // Fonction pour afficher les détails du produit dans le tableau
    function displayProductDetails(productId) {
      const xhr = new XMLHttpRequest();
      xhr.open('GET', 'get_produits_details.php?id=' + productId, true);
      xhr.onload = function() {
        if (xhr.status === 200) {
          const product = JSON.parse(xhr.responseText);

          let output = `<table >
                       <thead>
                         <tr>
                           <th>Nom du produit</th>
                           <th>Stock</th>
                           <th>Unité</th>
                           <th>Type</th>
                           <th>Quantité</th>
                           <th>Prix</th>
                           <th>Montant</th>
                         </tr>
                       </thead>
                       <tbody>
                         <tr>
                           <td>${product.nom_produit}</td>
                           <td>${product.caisse}</td>
                           <td>${product.quantite_produit}</td>
                           <td>
                             <select id="type_select" onchange="updatePrice(${product.prix_unite}, ${product.prix_caisse}); updateType(this.value)">
                                  <option value="">--Choisir--</option>
                                  <option value="unite">Unité</option>
                                  <option value="caisse">Caisse</option>
                                  </select>
                           </td>
                           <td><input type="number" id="quantite_input" value="1" min="1" oninput="calculateMontant()"></td>
                           <td id="prix_colonne"></td>
                           <td id="montant_colonne"></td>
                         </tr>
                       </tbody>
                     </table>`;

          // Afficher les détails du produit dans le div table_vente
          document.getElementById('table_vente').innerHTML = output;

          // Stockage de l'ID du produit
          produitId = productId;
        }
      };
      xhr.send();
    }

    // Fonction pour mettre à jour le type de produit
    function updateType(type) {
      typeProduit = type;
      updateFacture();
    }

    // Fonction pour mettre à jour le prix en fonction du type sélectionné
    function updatePrice(prixUnite, prixCaisse) {
      const typeSelect = document.getElementById('type_select').value;
      let prix;

      if (typeSelect === 'unite') {
        prix = prixUnite;
      } else if (typeSelect === 'caisse') {
        prix = prixCaisse;
      } else {
        prix = 0;
      }

      document.getElementById('prix_colonne').textContent = prix + " HTG";

      // Recalculer le montant lorsque le prix change
      calculateMontant();
    }

    // Fonction pour calculer le montant en fonction de la quantité et du prix
    function calculateMontant() {
      const quantite = parseInt(document.getElementById('quantite_input').value);
      const prix = parseFloat(document.getElementById('prix_colonne').textContent);

      if (!isNaN(quantite) && !isNaN(prix)) {
        const montant = quantite * prix;
        document.getElementById('montant_colonne').textContent = montant.toFixed(2) + " HTG";

        // Mise à jour des variables globales
        montantTotal = montant;
        quantiteProduit = quantite;

        // Mise à jour de la facture
        updateFacture();
      }
    }

    function updateFacture() {
      const nomProduit = document.querySelector(
        "#table_vente table tbody tr td:first-child"
      ).textContent;
      document.getElementById("facture_date").textContent =
        new Date().toLocaleDateString();
      document.getElementById("facture_nom_client").textContent =
        document.getElementById("nom_client").value;
      document.getElementById("facture_nom_produit").textContent = nomProduit;
      document.getElementById("facture_type").textContent = typeProduit;
      document.getElementById("facture_quantite").textContent = quantiteProduit;
      document.getElementById("facture_montant").textContent =
        montantTotal.toFixed(2) + " HTG";
    }

    function updateFactureNomClient() {
      const nomClient = document.getElementById("nom_client").value;
      document.getElementById("facture_nom_client").textContent = nomClient;
    }

    function calculerMontantRendre() {
      const montantRecu = parseFloat(document.getElementById("montant_recu").value);
      if (!isNaN(montantRecu)) {
        const montantRendre = montantRecu - montantTotal;
        document.getElementById("montant_rendre").value = montantRendre >= 0 ? montantRendre.toFixed(2) : "0.00";
        document.getElementById("balance").value = montantRendre < 0 ? (-montantRendre).toFixed(2) : "0.00";
      } else {
        document.getElementById("montant_rendre").value = "0.00";
        document.getElementById("balance").value = "0.00";
      }
    }

    function enregistrerVente() {
      const nomClient = document.getElementById("nom_client").value.trim();
      const montantRecu = parseFloat(document.getElementById("montant_recu").value);
      const balance = parseFloat(document.getElementById("balance").value);

      if (!nomClient) {
        afficherMessage('error', "Veuillez entrer le nom du client.");
        return;
      }

      if (isNaN(montantRecu) || montantRecu <= 0) {
        afficherMessage('error', "Veuillez entrer un montant reçu valide.");
        return;
      }

      if (montantTotal > 0 && produitId && quantiteProduit > 0 && typeProduit) {
        const xhr = new XMLHttpRequest();
        const data = `produit_id=${produitId}&quantite=${quantiteProduit}&type=${typeProduit}&prix_total=${montantTotal}&nom_client=${encodeURIComponent(nomClient)}&balance=${balance}&montant_recu=${montantRecu}`;
        xhr.open('POST', 'enregistrer_vente.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onload = function() {
          if (xhr.status === 200) {
            try {
              const response = JSON.parse(xhr.responseText);
              if (response.status === 'success') {
                afficherMessage('success', response.message);
              } else {
                afficherMessage('error', response.message);
              }
              annulerPaiement();
            } catch (e) {
              console.error('Réponse du serveur non valide:', xhr.responseText);
              afficherMessage('error', 'Erreur inattendue du serveur. Veuillez vérifier les logs.');
            }
          } else {
            afficherMessage('error', 'Erreur lors de l\'enregistrement de la vente.');
          }
        };
        xhr.onerror = function() {
          afficherMessage('error', 'Erreur de connexion au serveur.');
        };
        xhr.send(data);
      } else {
        afficherMessage('error', "Veuillez compléter tous les champs avant d'enregistrer la vente.");
      }
    }

    // Fonction pour afficher le message temporairement
    function afficherMessage(type, message) {
      const alertContainer = document.getElementById('alert-container');

      if (!alertContainer) return; // Vérifier si l'élément existe

      const alertMessage = document.createElement('div');
      alertMessage.className = `alert ${type}`; // Ajoute la classe pour le type de message

      // Ajouter l'icône correspondante pour le type de message
      let icon;
      switch (type) {
        case 'success':
          icon = '<i class="fas fa-check-circle"></i>'; // Icône pour succès
          break;
        case 'error':
          icon = '<i class="fas fa-exclamation-circle"></i>'; // Icône pour erreur
          break;
        case 'info':
          icon = '<i class="fas fa-info-circle"></i>'; // Icône pour information
          break;
        case 'warning':
          icon = '<i class="fas fa-exclamation-triangle"></i>'; // Icône pour avertissement
          break;
        default:
          icon = '';
      }

      alertMessage.innerHTML = `${icon} ${message}`; // Ajoute l'icône au message

      // Ajouter le message au conteneur d'alertes
      alertContainer.appendChild(alertMessage);

      // Masquer après 3 secondes
      setTimeout(() => {
        alertMessage.style.opacity = '0'; // Disparaître progressivement
        setTimeout(() => {
          alertMessage.remove(); // Retirer l'élément après la transition
        }, 500); // Délai pour la transition
      }, 3000); // 3 secondes avant disparition
    }


    function annulerPaiement() {
      // Réinitialiser les champs de la facture
      document.getElementById("facture_date").textContent = "";
      document.getElementById("facture_nom_produit").textContent = "";
      document.getElementById("facture_type").textContent = "";
      document.getElementById("facture_quantite").textContent = "";
      document.getElementById("facture_montant").textContent = "";
      document.getElementById("montant_recu").value = "";
      document.getElementById("montant_rendre").value = "";

      // Réinitialiser le tableau de vente
      document.getElementById("table_vente").innerHTML = "";

      // Réinitialiser les variables globales
      montantTotal = 0;
      produitId = null;
      typeProduit = "";
      quantiteProduit = 0;

      // Réinitialiser le champ de recherche
      document.getElementById("search").value = "";
    }
    // Modifier l'event listener pour le champ de recherche
    document.getElementById("search").addEventListener("input", function() {
      const search = this.value;
      rechercherProduits(search);
    });

    // Ajouter un event listener pour fermer les suggestions quand on clique ailleurs
    document.addEventListener("click", function(e) {
      if (!e.target.closest("#search") && !e.target.closest("#suggestions")) {
        document.getElementById("suggestions").style.display = "none";
      }
    });
  </script>

</body>

</html>