<?php
session_start();

// Rediriger vers la page de connexion si l'utilisateur n'est pas connecté
if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit();
}

// Vérifier si le nom d'utilisateur est défini dans la session
$username = isset($_SESSION['nom_utilisateur']) ? $_SESSION['nom_utilisateur'] : 'Utilisateur non connecté';

// Fonction pour vérifier les rôles
function checkRole($role)
{
    return isset($_SESSION['role']) && $_SESSION['role'] === $role;
}

// Vérifiez si l'utilisateur a le rôle requis pour accéder à cette page
if (!checkRole('admin')) {
    echo "Accès non autorisé.";
    exit();
}
function getNombreTotalProduits($conn)
{
    $sql = "SELECT COUNT(*) as total FROM produits";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    return $row['total'];
}

function getStocksDisponibles($conn)
{
    $sql = "SELECT SUM(caisse) as total FROM produits";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    return $row['total'];
}
function getMontantTotalVentes($conn)
{
    $sql = "SELECT SUM(prix_total) as total FROM ventes WHERE is_deleted=0";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    return $row['total'];
}
function getProduitsEnStockFaible($conn)
{
    $sql = "SELECT nom_produit, quantite_produit 
            FROM produits 
            WHERE quantite_produit <= 5 
            ORDER BY quantite_produit ASC 
            LIMIT 7";
    return $conn->query($sql);
}

// Inclure le fichier de connexion à la base de données
require_once '../config/database.php';

// Récupérer les données
$nombreProduits = getNombreTotalProduits($conn);
$stocksDisponibles = getStocksDisponibles($conn);
$montantVentes = getMontantTotalVentes($conn);
$produitsStockFaible = getProduitsEnStockFaible($conn);
?>


<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/dashboard.css">
    <link rel="stylesheet" href="../fontawesome/css/all.min.css">
    <link rel="icon" href="../images/Logo.png" type="image/x-icon">
    <title>Tableau de Bord</title>
</head>

<body>
    <header>
        <i class="fas fa-bars hamburger-menu"></i>
        <h3>La Suprise C&S Multi-Service</h3>
        <a href="../config/logout.php"><i class="fas fa-sign-out-alt"></i></a>
    </header>
    <div class="dashboard-container">
        <?php include_once '../includes/sidebar.php'; ?>

        <div class="main-content">
            <div class="overlay"></div>

            <section class="content">
                <div class="stats-summary">
                    <div class="stat-card">
                        <i class="fas fa-box"></i>
                        <h3>Produits</h3>
                        <p>Nombre total : <?php echo $nombreProduits; ?></p>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-warehouse"></i>
                        <h3>Stocks</h3>
                        <p>Caisses disponibles : <?php echo $stocksDisponibles; ?></p>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-shopping-cart"></i>
                        <h3>Montant des ventes</h3>
                        <p>Total : <?php echo $montantVentes; ?> HTG</p>
                    </div>
                </div>
                <hr class="diviseur">


                <div class="table-container">
                    <table class="styled-table">
                        <thead>
                            <div class="tabHead">
                                <h3>Produits épuisés ou en stock faible</h3>
                            </div>
                            <tr>
                                <th>Nom du produit</th>
                                <th>Quantité restante</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $produitsStockFaible->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['nom_produit']); ?></td>
                                    <td><?php echo $row['quantite_produit']; ?></td>
                                </tr>
                            <?php endwhile; ?>

                        </tbody>
                    </table>
                </div>
            </section>
            <footer>
                <small>&copy; <?php echo date("Y"); ?>La Suprise C&M Multi-Services. Tous droits réservés.</small>
            </footer>
        </div>

    </div>
</body>
<script src="../js/script.js"></script>

</html>