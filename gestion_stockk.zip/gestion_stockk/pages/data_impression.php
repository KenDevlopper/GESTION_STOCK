<?php
session_start();

/// Vérifier si l'utilisateur est connecté et est un administrateur
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
  header('Location: ../index.php');
  exit();
}
require_once '../config/database.php';

// Traitement du formulaire d'ajout
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $type = $_POST['type'];
  $taille = $_POST['taille'];
  $typePapier = $_POST['typePapier'];
  $categorie = $_POST['categorie'];
  $prix = $_POST['prix'];

  $sql = "INSERT INTO imprimerie (type, taille, type_papier, categorie, prix) VALUES (?, ?, ?, ?, ?)";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("ssssd", $type, $taille, $typePapier, $categorie, $prix);

  if ($stmt->execute()) {
    $_SESSION['message'] = ['type' => 'success', 'text' => 'Données enregistrées avec succès.'];
  } else {
    $_SESSION['message'] = ['type' => 'error', 'text' => 'Erreur lors de l\'enregistrement des données.'];
  }

  header('Location: ' . $_SERVER['PHP_SELF']);
  exit();
}
//Supprimer une donnee impression
if (isset($_GET['delete_id'])) {
  $delete_id = intval($_GET['delete_id']);
  $stmt = $conn->prepare("DELETE FROM imprimerie WHERE id = ?");
  $stmt->bind_param("i", $delete_id);

  if ($stmt->execute()) {
    $_SESSION['message'] = ['type' => 'success', 'text' => 'Donnée supprimée avec succès'];
  } else {
    $_SESSION['message'] = ['type' => 'error', 'text' => 'Erreur lors de la suppression de la Donnée  '];
  }

  $stmt->close();
  header('Location: data_impression.php');
  exit();
}
// Récupération des données pour l'affichage
$sql = "SELECT * FROM imprimerie";
$result = $conn->query($sql);

?>



<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../css/dataImpression.css">
  <link rel="stylesheet" href="../fontawesome/css/all.min.css">
  <link rel="shortcut icon" href="../images/Logo.png" type="image/x-icon">
  <title>Donnee Imprimerie</title>
  <style>
    /* Conteneur pour les messages */
    #alert-container {
      position: fixed;
      top: 10px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 1000;
    }

    /* Style de base pour les messages */
    .alert {
      padding: 15px;
      margin-bottom: 10px;
      border-radius: 5px;
      color: #fff;
      font-size: 16px;
      opacity: 1;
      transition: opacity 0.5s ease;
      display: flex;
      align-items: center;

    }

    /* Style pour les icônes */
    .alert i {
      margin-right: 10px;
      font-size: 20px;
    }

    /* Style pour les messages de succès */
    .alert.success {
      background-color: #28a745;
      border: 1px solid #1e7e34;
    }

    /* Style pour les messages d'erreur */
    .alert.error {
      background-color: #dc3545;
      border: 1px solid #c82333;
    }

    /* Style pour les messages d'information */
    .alert.info {
      background-color: #17a2b8;
      border: 1px solid #117a8b;
    }

    /* Style pour les messages d'avertissement */
    .alert.warning {
      background-color: #ffc107;
      border: 1px solid #e0a800;
    }
  </style>
</head>

<body>
  <header>
    <i class="fas fa-bars hamburger-menu"></i>
    <h3>La Suprise C&S Multi-Service</h3>
    <a href="../config/logout.php"><i class="fas fa-sign-out-alt"></i></a>
  </header>

  <!-- Div pour le message de succès -->
  <div id="alert-container"></div>

  <div class="dashboard-container">
    <?php include_once '../includes/sidebar.php'; ?>
    <div class="main-content">
      <div class="overlay"></div>
      <section class="content">
        <div class="titre">
          <h3>Données Imprimerie</h3>
        </div>

        <form method="POST" action="">
          <label for="type">Type:</label>
          <select name="type" id="type" required>
            <option value="">Choisir...</option>
            <option value="Couleur">Couleur</option>
            <option value="Noir & Blanc">Noir & Blanc</option>
            <option value="Scannerisation">Scannerisation</option>
          </select>
          <label for="taille">Taille:</label>
          <input type="text" name="taille" id="taille" required>
          <label for="typePapier">Type Papier:</label>
          <select name="typePapier" id="typePapier" required>
            <option value="">Choisir...</option>
            <option value="Papier blanc">Papier blanc</option>
            <option value="Bristol">Bristol</option>
            <option value="Papier photo">Papier photo</option>
          </select>
          <label for="categorie">Categorie:</label>
          <select name="categorie" id="categorie" required>
            <option value="">Choisir...</option>
            <option value="Impression">Impression</option>
            <option value="Copie">Copie</option>
          </select>
          <label for="prix">Prix:</label>
          <input type="number" name="prix" id="prix" step="0.01" required>
          <button type="submit">Enregistrer</button>
        </form>

        <div class="table-container">
          <table class="styled-table">
            <thead>
              <div class="tabHead">
                <h3>Données Imprimerie</h3>
              </div>
              <tr>
                <th>Type impression</th>
                <th>Taille</th>
                <th>Type Papier</th>
                <th>Categorie</th>
                <th>Prix</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php
              if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                  echo "<tr>";
                  echo "<td>" . htmlspecialchars($row['type']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['taille']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['type_papier']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['categorie']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['prix']) . " HTG</td>";
                  echo "<td>";
                  echo "<button class='btnSup'><a href='?delete_id=" . $row['id'] . "'>Supprimer</a></button>";
                  echo "</td>";
                  echo "</tr>";
                }
              } else {
                echo "<tr><td colspan='6'style='text-align: center;'>Aucune donnée trouvée</td></tr>";
              }
              ?>

            </tbody>
          </table>
        </div>
      </section>
      <?php include_once '../includes/footer.php'; ?>
    </div>
  </div>

  <script src="../js/script.js"> </script>
  <script>
    // Fonction pour afficher le message
    function afficherMessage(type, message) {
      const alertContainer = document.getElementById('alert-container');
      if (!alertContainer) return;

      const alertMessage = document.createElement('div');
      alertMessage.className = `alert ${type}`;

      let icon;
      switch (type) {
        case 'success':
          icon = '<i class="fas fa-check-circle"></i>';
          break;
        case 'error':
          icon = '<i class="fas fa-exclamation-circle"></i>';
          break;
        case 'info':
          icon = '<i class="fas fa-info-circle"></i>';
          break;
        case 'warning':
          icon = '<i class="fas fa-exclamation-triangle"></i>';
          break;
        default:
          icon = '';
      }

      alertMessage.innerHTML = `${icon} ${message}`;
      alertContainer.appendChild(alertMessage);

      setTimeout(() => {
        alertMessage.style.opacity = '0';
        setTimeout(() => alertMessage.remove(), 500);
      }, 3000);
    }
    // Vérifier et afficher le message de session au chargement de la page
    document.addEventListener('DOMContentLoaded', function() {
      <?php
      if (isset($_SESSION['message'])) {
        echo "afficherMessage('" . $_SESSION['message']['type'] . "', '" . addslashes($_SESSION['message']['text']) . "');";
        unset($_SESSION['message']);
      }
      ?>
    });
  </script>

</body>

</html>