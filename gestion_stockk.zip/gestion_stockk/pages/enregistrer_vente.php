<?php
session_start();
require_once '../config/database.php';

$response = array(); // Tableau pour la réponse JSON

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $produit_id = $_POST['produit_id'];
  $quantite = $_POST['quantite'];
  $type = $_POST['type'];
  $prix_total = $_POST['prix_total'];
  $date_vente = date('Y-m-d H:i:s');
  $nom_client = $_POST['nom_client'];
  $balance = $_POST['balance'];
  $nom_utilisateur = $_SESSION['nom_utilisateur']; // Récupération du nom d'utilisateur de la session

  // Début de la transaction
  $conn->begin_transaction();

  try {
    // Récupérer les informations actuelles du produit
    $stmt = $conn->prepare("SELECT caisse, quantite_produit FROM produits WHERE id = ?");
    $stmt->bind_param("i", $produit_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $produit = $result->fetch_assoc();

    if (!$produit) {
      throw new Exception("Produit non trouvé.");
    }

    $caisse_a_reduire = 0;
    $unite_a_reduire = 0;

    if ($type === 'caisse') {
      if ($quantite > $produit['caisse']) {
        throw new Exception("Quantité de caisses demandées dépasse le stock disponible.");
      }
      $caisse_a_reduire = $quantite;
      $unite_a_reduire = $quantite * 24;
    } elseif ($type === 'unite') {
      $unite_a_reduire = $quantite;
      $caisse_a_reduire = intdiv($quantite, 24);
      $reste_unites = ($quantite % 24) + $caisse_a_reduire * 24;

      if ($produit['caisse'] < $caisse_a_reduire || $produit['quantite_produit'] < $reste_unites) {
        throw new Exception("Stock insuffisant.");
      }

      if ($reste_unites > 0) {
        $unite_a_reduire = $reste_unites;
      } else {
        $unite_a_reduire = $quantite;
      }
    }

    $nouvelle_caisse = $produit['caisse'] - $caisse_a_reduire;
    $nouvelle_quantite_produit = $produit['quantite_produit'] - $unite_a_reduire;

    if ($nouvelle_quantite_produit < 24) {
      $nouvelle_caisse = 0;
    } else {
      if ($nouvelle_quantite_produit > 24) {
        $nouvelle_caisse = floor($nouvelle_quantite_produit / 24);
        $nouvelle_quantite_produit = ($nouvelle_quantite_produit % 24) + $nouvelle_caisse * 24;
      }
    }

    $stmt = $conn->prepare("INSERT INTO ventes (produit_id, quantite, type, prix_total, date_vente, nom_client, balance, nom_utilisateur) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param('iisdssss', $produit_id, $quantite, $type, $prix_total, $date_vente, $nom_client, $balance, $nom_utilisateur);
    $stmt->execute();

    $stmt = $conn->prepare("UPDATE produits SET caisse = ?, quantite_produit = ? WHERE id = ?");
    $stmt->bind_param("iii", $nouvelle_caisse, $nouvelle_quantite_produit, $produit_id);
    $stmt->execute();

    $conn->commit();
    $response['status'] = 'success';
    $response['message'] = 'Vente enregistrée et stock mis à jour avec succès';
  } catch (Exception $e) {
    $conn->rollback();
    $response['status'] = 'error';
    $response['message'] = 'Erreur lors de l\'enregistrement de la vente: ' . $e->getMessage();
  }

  $stmt->close();
  $conn->close();

  // Envoyer la réponse JSON
  header('Content-Type: application/json');
  echo json_encode($response);
}
