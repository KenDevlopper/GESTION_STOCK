<?php
require_once '../config/database.php';

function getPrix($conn, $type, $taille, $typePapier, $categorie)
{
  $sql = "SELECT prix FROM imprimerie WHERE type = ? AND taille = ? AND type_papier = ? AND categorie = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("ssss", $type, $taille, $typePapier, $categorie);
  $stmt->execute();
  $result = $stmt->get_result();
  if ($row = $result->fetch_assoc()) {
    return $row['prix'];
  }
  return null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $type = $_POST['type'];
  $taille = $_POST['taille'];
  $typePapier = $_POST['typePapier'];
  $categorie = $_POST['categorie'];

  $prix = getPrix($conn, $type, $taille, $typePapier, $categorie);
  echo $prix !== null ? $prix : 'Prix non trouvé';
}
