<?php
// Inclure la connexion à la base de données
require_once '../config/database.php';

if (isset($_GET['id']) && !empty($_GET['id'])) {
  $id = htmlspecialchars($_GET['id']);

  // Préparer la requête pour obtenir les détails du produit
  $stmt = $conn->prepare("SELECT * FROM produits WHERE id = ?");
  $stmt->bind_param('i', $id);
  $stmt->execute();
  $result = $stmt->get_result();

  $product = $result->fetch_assoc();

  // Retourner les résultats sous forme de JSON
  echo json_encode($product);
  $stmt->close();
}
