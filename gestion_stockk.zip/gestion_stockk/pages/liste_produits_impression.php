<?php
date_default_timezone_set('America/Port-au-Prince');
session_start();

// Vérifier si l'utilisateur est connecté et est un administrateur
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
  header('Location: ../index.php');
  exit();
}

require_once '../config/database.php';

$order = isset($_GET['order']) ? $_GET['order'] : 'DESC';
$date_debut = isset($_GET['date_debut']) ? $_GET['date_debut'] : '';
$date_fin = isset($_GET['date_fin']) ? $_GET['date_fin'] : '';
$search = isset($_GET['search']) ? $_GET['search'] : '';

$sql = "SELECT * FROM produit_impression WHERE is_deleted = 0";

if ($date_debut && $date_fin) {
  $sql .= " AND DATE(date_vente) BETWEEN DATE('$date_debut') AND DATE('$date_fin')";
}

if ($search) {
  $sql .= " AND nom_client LIKE '%$search%'";
}

$sql .= " ORDER BY date_vente $order";

error_log("Requête SQL exécutée : " . $sql);

$result = $conn->query($sql);

if (!$result) {
  error_log("Erreur dans la requête : " . $conn->error);
  die("Une erreur est survenue lors de la récupération des données.");
}

?>

<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../css/listeService.css">
  <link rel="stylesheet" href="../fontawesome/css/all.min.css">
  <link rel="stylesheet" href="../css/impressionVente.css">
  <link rel="shortcut icon" href="../images/Logo.png" type="image/x-icon">
  <title>Liste des ventes Produits d'Impression</title>
  <style>
    /* Conteneur pour les messages */
    #alert-container {
      position: fixed;
      top: 10px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 1000;
    }

    /* Style de base pour les messages */
    .alert {
      padding: 15px;
      margin-bottom: 10px;
      border-radius: 5px;
      color: #fff;
      font-size: 16px;
      opacity: 1;
      transition: opacity 0.5s ease;
      display: flex;
      align-items: center;

    }

    /* Style pour les icônes */
    .alert i {
      margin-right: 10px;
      font-size: 20px;
    }

    /* Style pour les messages de succès */
    .alert.success {
      background-color: #28a745;
      border: 1px solid #1e7e34;
    }

    /* Style pour les messages d'erreur */
    .alert.error {
      background-color: #dc3545;
      border: 1px solid #c82333;
    }

    /* Style pour les messages d'information */
    .alert.info {
      background-color: #17a2b8;
      border: 1px solid #117a8b;
    }

    /* Style pour les messages d'avertissement */
    .alert.warning {
      background-color: #ffc107;
      border: 1px solid #e0a800;
    }
  </style>
</head>

<body>
  <header>
    <i class="fas fa-bars hamburger-menu"></i>
    <h3>Suprise C&S Multi-Service</h3>
    <a href="../config/logout.php"><i class="fas fa-sign-out-alt"></i></a>
  </header>

  <div id="alert-container"></div>

  <div class="dashboard-container">
    <?php include_once '../includes/sidebar.php'; ?>
    <div class="main-content">
      <div class="overlay"></div>
      <section class="content">
        <div class="actions no-print">
          <div class="titre">
            <h2>Liste des ventes des produits d'impressions</h2>
            <hr>
          </div>
          <form method="GET" id="searchForm">
            <div class="form-group">
              <label for="date_debut">Date début:</label>
              <input type="date" id="date_debut" name="date_debut" value="<?php echo $date_debut; ?>">
            </div>

            <div class="form-group">
              <label for="date_fin">Date fin:</label>
              <input type="date" id="date_fin" name="date_fin" value="<?php echo $date_fin; ?>">
            </div>

            <div class="form-group">
              <label for="search">Rechercher un client:</label>
              <input type="text" id="search" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Nom du client">
            </div>

            <div class="btn-group">
              <button type="button" onclick="resetAndRefresh()" class="btn btn-reset"><i class="fas fa-undo"></i> Reset</button>
              <button onclick="imprimerTout()" type="button" class="btn btn-print"> <i class="fas fa-print"></i> Imprimer Tout</button>
              <button onclick="supprimerTout()" type="button" class="btn btn-danger"> <i class="fas fa-trash-alt"></i> Supprimer Tout</button>
            </div>
          </form>
        </div>
        <div class="table-container">
          <table class="styled-table">
            <thead>
              <tr>
                <th>Nom Client</th>
                <th>Nom Produit</th>
                <th>Quantité</th>
                <th>Prix Unitaire</th>
                <th>Prix Total</th>
                <th>Employé</th>
                <th>Date de vente <a class="order no-print" href="?order=<?php echo $order == 'ASC' ? 'DESC' : 'ASC'; ?>">
                    <?php echo $order == 'ASC' ? '▲' : '▼'; ?>
                  </a></th>
                <th class="no-print">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php
              if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                  echo "<tr>";
                  echo "<td>" . htmlspecialchars($row['nom_client']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['type_produit']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['quantite']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['prix']) . " HTG</td>";
                  echo "<td>" . htmlspecialchars($row['prix_total']) . " HTG</td>";
                  echo "<td>" . htmlspecialchars($row['nom_utilisateur']) . "</td>";
                  echo "<td>" . date('d-m-Y', strtotime($row['date_vente'])) . "</td>";
                  echo "<td class='no-print'><button onclick='imprimerProduit(" . $row['id'] . ")' class='btn'>Imprimer</button></td>";
                  echo "</tr>";
                }
              } else {
                echo "<tr><td colspan='8' style='text-align: center;'>Aucun produit d'impression trouvé</td></tr>";
              }
              ?>
            </tbody>
          </table>
        </div>
      </section>
      <footer>
        <small>&copy; <?php echo date("Y"); ?>La Suprise C&M Multi-Services. Tous droits réservés.</small>
      </footer>
    </div>
  </div>

  <!-- Ajoutez cette nouvelle div pour la boîte de dialogue modale juste avant la fermeture de la balise body -->
  <div id="customAlert" class="custom-alert">
    <div class="alert-content">
      <h2>Confirmation</h2>
      <p>Êtes-vous sûr de vouloir supprimer la liste des produits d'impression ?</p>
      <div class="alert-buttons">
        <button id="confirmDelete" class="btn btn-danger">Supprimer</button>
        <button id="cancelDelete" class="btn">Annuler</button>
      </div>
    </div>
  </div>

  <script src="../js/script.js"></script>
  <script>
    function imprimerProduit(id) {
      window.open(`imprimer_produit.php?id=${id}`, '_blank');
    }

    function imprimerTout() {
      window.print();
    }

    // Remplacez la fonction supprimerTout() par celle-ci :
    function supprimerTout() {
      document.getElementById('customAlert').style.display = 'flex';
    }

    document.getElementById('confirmDelete').addEventListener('click', function() {
      document.getElementById('customAlert').style.display = 'none';
      fetch('supprimer_produits_impression.php', {
          method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            location.reload();
          } else {
            afficherMessage('error', "Erreur lors de la suppression des produits d'impression");
          }
        });
    });

    document.getElementById('cancelDelete').addEventListener('click', function() {
      document.getElementById('customAlert').style.display = 'none';
    });

    // Fonction pour afficher le message (comme dans le fichier original)
    function afficherMessage(type, message) {
      // ... (code inchangé)
    }

    // Vérifier et afficher le message de session au chargement de la page
    document.addEventListener('DOMContentLoaded', function() {
      <?php
      if (isset($_SESSION['message'])) {
        echo "afficherMessage('" . $_SESSION['message']['type'] . "', '" . addslashes($_SESSION['message']['text']) . "');";
        unset($_SESSION['message']);
      }
      ?>

      const searchInput = document.getElementById('search');
      const searchForm = document.querySelector('form');

      searchInput.addEventListener('input', function() {
        clearTimeout(this.timer);
        this.timer = setTimeout(function() {
          searchForm.submit();
        }, 500);
      });

      document.getElementById('date_debut').addEventListener('change', function() {
        searchForm.submit();
      });

      document.getElementById('date_fin').addEventListener('change', function() {
        searchForm.submit();
      });
    });

    function resetAndRefresh() {
      // Réinitialiser les champs de date et de recherche
      document.getElementById('date_debut').value = '';
      document.getElementById('date_fin').value = '';
      document.getElementById('search').value = '';

      // Soumettre le formulaire pour actualiser la table
      document.getElementById('searchForm').submit();
    }
  </script>

</body>

</html>

<?php
$conn->close();
?>