<?php
session_start();
require_once '../config/database.php';

// Vérifier si l'utilisateur est connecté et est un administrateur
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
  header('Location: ../index.php');
  exit();
}

// Traitement de la suppression
if (isset($_POST['delete'])) {
  $id_to_delete = $_POST['delete'];
  $delete_sql = "DELETE FROM utilisateurs WHERE id = ?";
  $stmt = $conn->prepare($delete_sql);
  $stmt->bind_param("i", $id_to_delete);
  if ($stmt->execute()) {
    $_SESSION['message'] = ['type' => 'success', 'text' => 'l\'employé a été supprimé avec succès.'];
  } else {
    $_SESSION['message'] = ['type' => 'error', 'text' => 'Erreur lors de la suppression de l\'employé.'];
  }
  $stmt->close();
  header('Location: lister_employes.php');
  exit();
}

// Récupérer la liste des employés
$sql = "SELECT id, nom_utilisateur, role FROM utilisateurs WHERE role = 'employe'";
$result = $conn->query($sql);

// ... (le reste du code PHP reste inchangé)
?>

<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Liste Employes</title>
  <link rel="stylesheet" href="../css/listerEmploye.css">
  <link rel="stylesheet" href="../fontawesome/css/all.min.css">
  <link rel="shortcut icon" href="../images/Logo.png" type="image/x-icon">
  <style>
    /* Conteneur pour les messages */
    #alert-container {
      position: fixed;
      top: 10px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 1000;
    }

    /* Style de base pour les messages */
    .alert {
      padding: 15px;
      margin-bottom: 10px;
      border-radius: 5px;
      color: #fff;
      font-size: 16px;
      opacity: 1;
      transition: opacity 0.5s ease;
      display: flex;
      align-items: center;

    }

    /* Style pour les icônes */
    .alert i {
      margin-right: 10px;
      font-size: 20px;
    }

    /* Style pour les messages de succès */
    .alert.success {
      background-color: #28a745;
      border: 1px solid #1e7e34;
    }

    /* Style pour les messages d'erreur */
    .alert.error {
      background-color: #dc3545;
      border: 1px solid #c82333;
    }

    /* Style pour les messages d'information */
    .alert.info {
      background-color: #17a2b8;
      border: 1px solid #117a8b;
    }

    /* Style pour les messages d'avertissement */
    .alert.warning {
      background-color: #ffc107;
      border: 1px solid #e0a800;
    }
  </style>
</head>

<body>
  <header>
    <i class="fas fa-bars hamburger-menu"></i>
    <h3>La Suprise C&S Multi-Service</h3>
    <a href="../config/logout.php"><i class="fas fa-sign-out-alt"></i></a>
  </header>

  <!-- Div pour le message de succès -->
  <div id="alert-container"></div>

  <div class="dashboard-container">
    <?php include_once '../includes/sidebar.php'; ?>

    <div class="main-content">
      <div class="overlay"></div>
      <section class="content">
        <div class="table-container">

          <?php if ($result->num_rows > 0): ?>
            <table class="responsive-table">
              <thead>
                <div class="tabHead">
                  <h2>Liste des Employés</h2>
                </div>

                <tr>
                  <th>ID</th>
                  <th>Nom d'utilisateur</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                  <tr>
                    <td><?php echo htmlspecialchars($row['id']); ?></td>
                    <td><?php echo htmlspecialchars($row['nom_utilisateur']); ?></td>
                    <td>
                      <a href="modifier_employe.php?id=<?php echo $row['id']; ?>" class="btn btn-edit"><i class="fas fa-edit"></i> Modifier</a>
                      <form method="POST" style="display: inline;">
                        <button type="submit" name="delete" value="<?php echo $row['id']; ?>" class="btn btn-delete"><i class="fas fa-trash-alt"></i> Supprimer</button>
                      </form>
                    </td>
                  </tr>
                <?php endwhile; ?>
              </tbody>
            </table>
          <?php else: ?>
            <p style="text-align: center;">Aucun employé trouvé.</p>
          <?php endif; ?>



        </div>
      </section>
      <footer no-print>
        <small>&copy; <?php echo date("Y"); ?>La Suprise C&M Multi-Services. Tous droits réservés.</small>
      </footer>
    </div>


  </div>

  <script src="../js/script.js"></script>
  <script>
    // Fonction pour afficher le message
    function afficherMessage(type, message) {
      const alertContainer = document.getElementById('alert-container');
      if (!alertContainer) return;

      const alertMessage = document.createElement('div');
      alertMessage.className = `alert ${type}`;

      let icon;
      switch (type) {
        case 'success':
          icon = '<i class="fas fa-check-circle"></i>';
          break;
        case 'error':
          icon = '<i class="fas fa-exclamation-circle"></i>';
          break;
        case 'info':
          icon = '<i class="fas fa-info-circle"></i>';
          break;
        case 'warning':
          icon = '<i class="fas fa-exclamation-triangle"></i>';
          break;
        default:
          icon = '';
      }

      alertMessage.innerHTML = `${icon} ${message}`;
      alertContainer.appendChild(alertMessage);

      setTimeout(() => {
        alertMessage.style.opacity = '0';
        setTimeout(() => alertMessage.remove(), 500);
      }, 3000);
    }
    // Vérifier et afficher le message de session au chargement de la page
    document.addEventListener('DOMContentLoaded', function() {
      <?php
      if (isset($_SESSION['message'])) {
        echo "afficherMessage('" . $_SESSION['message']['type'] . "', '" . addslashes($_SESSION['message']['text']) . "');";
        unset($_SESSION['message']);
      }
      ?>
    });
  </script>
</body>

</html>

<?php
$conn->close();
?>