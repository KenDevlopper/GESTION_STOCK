<?php
session_start();
// Vérifier si l'utilisateur est connecté et est un administrateur
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
  header('Location: ../index.php');
  exit();
}
require_once '../config/database.php';


// Traitement du tri par date
$order = isset($_GET['order']) ? $_GET['order'] : 'DESC';
$date_debut = isset($_GET['date_debut']) ? $_GET['date_debut'] : '';
$date_fin = isset($_GET['date_fin']) ? $_GET['date_fin'] : '';
$search = isset($_GET['search']) ? $_GET['search'] : '';

// Requête SQL combinée pour les ventes générales et les ventes d'eau
$sql = "SELECT * FROM (
  SELECT 'general' as type, v.id, p.nom_produit, v.quantite, v.type as vente_type, v.prix_total, v.date_vente, v.nom_client, v.balance, v.nom_utilisateur
  FROM ventes v 
  JOIN produits p ON v.produit_id = p.id
  WHERE v.is_deleted = 0  -- Ajout de la condition pour vérifier si la vente n'est pas supprimée
  UNION ALL
  SELECT 'eau' as type, ve.id, 'Eau' as nom_produit, ve.quantite, ve.type_eau as vente_type, ve.prix_total, ve.date_vente, ve.nom_client, ve.balance, ve.nom_utilisateur
  FROM ventes_eau ve
  WHERE ve.is_deleted = 0  -- Ajout de la condition pour vérifier si la vente d'eau n'est pas supprimée
) AS combined_sales
WHERE 1=1";

if ($date_debut && $date_fin) {
  $sql .= " AND (date_vente BETWEEN '$date_debut' AND '$date_fin')";
}

if ($search) {
  $sql .= " AND nom_client LIKE '%$search%'";
}

$sql .= " ORDER BY date_vente $order";

$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Liste des Ventes</title>
  <link rel="stylesheet" href="../css/listerVentes.css">
  <link rel="stylesheet" href="../fontawesome/css/all.min.css">
  <link rel="stylesheet" href="../css/impressionVente.css">
  <link rel="shortcut icon" href="../images/Logo.png" type="image/x-icon">
</head>

<body>
  <header class="no-print">
    <i class="fas fa-bars hamburger-menu"></i>
    <h3>Suprise C&S Multi-Service</h3>
    <a href="../config/logout.php"><i class="fas fa-sign-out-alt"></i></a>
  </header>


  <div class="dashboard-container">
    <?php include_once '../includes/sidebar.php'; ?>

    <div class="main-content">
      <div class="overlay"></div>
      <section class="content">
        <div class="actions no-print">
          <div class="titre">
            <h2>Liste des Ventes</h2>
            <hr>
          </div>
          <form method="GET" id="searchForm">
            <div class="form-group">
              <label for="date_debut">Date début:</label>
              <input type="date" id="date_debut" name="date_debut" value="<?php echo $date_debut; ?>">
            </div>

            <div class="form-group">
              <label for="date_fin">Date fin:</label>
              <input type="date" id="date_fin" name="date_fin" value="<?php echo $date_fin; ?>">
            </div>

            <div class="form-group">
              <label for="search">Rechercher un client:</label>
              <input type="text" id="search" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Nom du client">
            </div>

            <div class="btn-group">
              <button type="button" onclick="resetAndRefresh()" class="btn btn-reset"><i class="fas fa-undo"></i> Reset</button>
              <button type="button" onclick="imprimerTout()" class="btn btn-print"><i class="fas fa-print"></i> Imprimer Tout</button>
              <button type="button" onclick="supprimerTout()" class="btn btn-danger"><i class="fas fa-trash-alt"></i> Supprimer Tout</button>
            </div>
          </form>
        </div>

        <div class="table-container">
          <table class="responsive-table">
            <thead>
              <tr>
                <th>Nom du Client</th>
                <th>Produit</th>
                <th>Quantité</th>
                <th>Type</th>
                <th>Prix Total</th>
                <th>Balance</th>
                <th>Employé</th>
                <th>Date de Vente <a class="order no-print" href="?order=<?php echo $order == 'ASC' ? 'DESC' : 'ASC'; ?>">
                    <?php echo $order == 'ASC' ? '▲' : '▼'; ?>
                  </a></th>
                <th class="no-print">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php
              if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                  echo "<tr>";
                  echo "<td data-label='Nom du Client'>" . htmlspecialchars($row['nom_client']) . "</td>";
                  echo "<td data-label='Produit'>" . htmlspecialchars($row['nom_produit']) . "</td>";
                  echo "<td data-label='Quantité'>" . htmlspecialchars($row['quantite']) . "</td>";
                  echo "<td data-label='Type'>" . htmlspecialchars($row['vente_type']) . "</td>";
                  echo "<td data-label='Prix Total'>" . htmlspecialchars($row['prix_total']) . " HTG</td>";
                  echo "<td data-label='Balance'>" . htmlspecialchars($row['balance']) . " HTG</td>";
                  echo "<td data-label='Employé'>" . htmlspecialchars($row['nom_utilisateur']) . "</td>";
                  echo "<td data-label='Date de Vente'>" . htmlspecialchars($row['date_vente']) . "</td>";
                  echo "<td data-label='Action' class='no-print'>";
                  if ($row['type'] == 'general') {
                    echo "<button onclick='imprimerVente(" . $row['id'] . ")' class='btn'>  Imprimer</button>";
                  } else {
                    echo "<button onclick='imprimerVenteEau(" . $row['id'] . ")' class='btn'>Imprimer</button>";
                  }
                  echo "</td>";
                  echo "</tr>";
                }
              } else {
                echo "<tr><td colspan='9' style='text-align:center;'>Aucune vente trouvée</td></tr>";
              }
              ?>
            </tbody>
          </table>
        </div>

      </section>
      <footer class="no-print">
        <small>&copy; <?php echo date("Y"); ?> Suprise C&M Multi-Services. Tous droits réservés.</small>
      </footer>
    </div>


  </div>




  <div id="customAlert" class="custom-alert">
    <div class="alert-content">
      <h2>Confirmation</h2>
      <p>Êtes-vous sûr de vouloir supprimer toutes les ventes ?</p>
      <div class="alert-buttons">
        <button id="confirmDelete" class="btn btn-danger">Supprimer</button>
        <button id="cancelDelete" class="btn">Annuler</button>
      </div>
    </div>
  </div>

  <script src="../js/script.js"></script>
  <script>
    // Fonction pour imprimer une vente spécifique
    function imprimerVente(id) {
      window.open(`imprimer_vente.php?id=${id}`, '_blank');
    }

    // Fonction pour imprimer toutes les ventes
    function imprimerTout() {
      window.print();
    }

    // Remplacez la fonction supprimerTout() par celle-ci :
    function supprimerTout() {
      document.getElementById('customAlert').style.display = 'flex';
    }

    document.getElementById('confirmDelete').addEventListener('click', function() {
      document.getElementById('customAlert').style.display = 'none';
      fetch('supprimer_ventes.php', {
          method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            location.reload();
          } else {
            alert("Erreur lors de la suppression des ventes");
          }
        });
    });

    document.getElementById('cancelDelete').addEventListener('click', function() {
      document.getElementById('customAlert').style.display = 'none';
    });

    window.onbeforeprint = function() {
      var pageCount = Math.ceil(document.body.scrollHeight / 1123); // A4 height in pixels at 96 DPI
      document.querySelector('.page-count').textContent = pageCount;
    };

    // Ajoutez cette nouvelle fonction
    document.addEventListener('DOMContentLoaded', function() {
      const searchInput = document.getElementById('search');
      const searchForm = document.getElementById('searchForm');

      searchInput.addEventListener('input', function() {
        // Soumettre le formulaire après un court délai pour éviter trop de requêtes
        clearTimeout(this.timer);
        this.timer = setTimeout(function() {
          searchForm.submit();
        }, 500);
      });

      // Écouter les changements sur les champs de date également
      document.getElementById('date_debut').addEventListener('change', function() {
        searchForm.submit();
      });

      document.getElementById('date_fin').addEventListener('change', function() {
        searchForm.submit();
      });
    });

    // Ajoutez cette nouvelle fonction pour imprimer une vente d'eau spécifique
    function imprimerVenteEau(id) {
      window.open(`imprimer_vente_eau.php?id=${id}`, '_blank');
    }

    // Ajoutez cette nouvelle fonction
    function resetAndRefresh() {
      // Réinitialiser les champs de date et de recherche
      document.getElementById('date_debut').value = '';
      document.getElementById('date_fin').value = '';
      document.getElementById('search').value = '';

      // Soumettre le formulaire pour actualiser la table
      document.getElementById('searchForm').submit();
    }
  </script>
</body>

</html>

<?php
$conn->close();
?>