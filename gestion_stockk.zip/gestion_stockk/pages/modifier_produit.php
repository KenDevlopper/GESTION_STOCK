<?php
session_start();

// Vérifier si l'utilisateur est connecté et est un administrateur
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../index.php');
    exit();
}

require_once '../config/database.php';

// Vérifier si l'ID du produit est envoyé
if (!isset($_GET['id'])) {
    header('Location: lister_produits.php');
    exit();
}

$product_id = intval($_GET['id']);

// Récupérer les informations du produit
$stmt = $conn->prepare("SELECT p.id, p.nom_produit, p.description, p.prix_unite, p.caisse, p.unite, p.prix_caisse, p.quantite_produit, p.id_categorie, c.nom_categorie 
                        FROM produits p 
                        JOIN categories c ON p.id_categorie = c.id 
                        WHERE p.id = ?");

$stmt->bind_param("i", $product_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    header('Location: lister_produits.php');
    exit();
}

$product = $result->fetch_assoc();

// Formulaire de modification du produit
if (isset($_POST['submit'])) {
    $nom_produit = trim($_POST['nom_produit']);
    $description = trim($_POST['description']);
    $prix_unite = floatval($_POST['prix_unite']);
    $caisse = intval($_POST['caisse']);
    $unite = intval($_POST['unite']);
    $prix_caisse = floatval($_POST['prix_caisse']);
    $categorie_id = intval($_POST['id_categorie']);

    $quantite = $unite+($caisse * 24);

    // Valider les données
    if (empty($nom_produit) || empty($description) || $prix_unite <= 0 || $caisse <= 0 || $unite <= 0|| $prix_caisse <= 0) {
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Veuillez remplir tous les champs obligatoire'];
    } else {
        // Mettre à jour le produit
        $stmt = $conn->prepare("UPDATE produits SET nom_produit = ?, description = ?, prix_unite = ?, caisse = ?, unite = ?, prix_caisse = ?, quantite_produit = ?, id_categorie = ? WHERE id = ?");
        $stmt->bind_param("ssdiiiiii", $nom_produit, $description, $prix_unite, $caisse, $unite, $prix_caisse, $quantite, $categorie_id, $product_id);
        if ($stmt->execute()) {
            $_SESSION['message'] = ['type' => 'success', 'text' => 'Produit mis à jour avec succès !'];
            header('Location: lister_produits.php?');
            exit();
        } else {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Erreur lors de la mise à jour du produit'];
        }
    }
}

// Récupérer les catégories pour le formulaire
$stmt = $conn->prepare("SELECT id, nom_categorie FROM categories");
$stmt->execute();
$categories = $stmt->get_result();

?>



<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/modifierProduit.css">
    <link rel="stylesheet" href="../fontawesome/css/all.min.css">
    <link rel="shortcut icon" href="../images/Logo.png" type="image/x-icon">
    <title>Modifier Produit</title>
    <style>
        /* Conteneur pour les messages */
        #alert-container {
            position: fixed;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 1000;
        }

        /* Style de base pour les messages */
        .alert {
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 5px;
            color: #fff;
            font-size: 16px;
            opacity: 1;
            transition: opacity 0.5s ease;
            display: flex;
            align-items: center;

        }

        /* Style pour les icônes */
        .alert i {
            margin-right: 10px;
            font-size: 20px;
        }

        /* Style pour les messages de succès */
        .alert.success {
            background-color: #28a745;
            border: 1px solid #1e7e34;
        }

        /* Style pour les messages d'erreur */
        .alert.error {
            background-color: #dc3545;
            border: 1px solid #c82333;
        }

        /* Style pour les messages d'information */
        .alert.info {
            background-color: #17a2b8;
            border: 1px solid #117a8b;
        }

        /* Style pour les messages d'avertissement */
        .alert.warning {
            background-color: #ffc107;
            border: 1px solid #e0a800;
        }
    </style>
</head>

<body>
    <header>
        <i class="fas fa-bars hamburger-menu"></i>
        <h3>La Suprise C&S Multi-Service</h3>
        <a href="../config/logout.php"><i class="fas fa-sign-out-alt"></i></a>
    </header>

    <!-- Div pour le message de succès -->
    <div id="alert-container"></div>


    <div class="dashboard-container">
        <?php include_once '../includes/sidebar.php'; ?>

        <div class="main-content">
            <div class="overlay"></div>
            <section class="content">
                <div class="titre">
                    <h3>MODIFICATION PRODUIT</h3>
                </div>


                <form method="POST" action="modifier_produit.php?id=<?php echo $product_id; ?>">
                    <div class="form-row">
                        <div class="form-colonne">
                            <label for="nom_produit">Nom du produit:</label>
                            <input type="text" name="nom_produit" id="nom_produit" value="<?php echo htmlspecialchars($product['nom_produit']); ?>" required>

                            <label for="description">Description:</label>
                            <textarea name="description" id="description" placeholder="Description du produit"><?php echo htmlspecialchars($product['description']); ?></textarea>

                            <label for="prix">Prix:</label>
                            <input type="number" name="prix_unite" id="prix_unite" value="<?php echo $product['prix_unite']; ?>" required>
                        </div>

                        <div class="form-colonne">
                            <label for="caisse">Stock / Caisse</label>
                            <input type="number" name="caisse" id="caisse" value="<?php echo $product['caisse']; ?>" readonly>
                            <label for="unite">Stock / Unité:</label>
                            <input type="number" name="unite" id="unite" value="<?php echo $product['unite']; ?>" required>
                            <label for="caisse">Prix / Caisse:</label>
                            <input type="number" name="prix_caisse" id="prix_caisse" value="<?php echo $product['prix_caisse']; ?>" required>
                            <label for="id_categorie">Catégorie:</label>
                            <select name="id_categorie" id="id_categorie" required>
                                <option value="">Sélectionner une catégorie</option>
                                <?php
                                if ($categories->num_rows > 0) {
                                    while ($row = $categories->fetch_assoc()) {
                                        // Vérifie si la catégorie du produit correspond à l'ID de la catégorie actuelle
                                        $selected = ($row['id'] == $product['id_categorie']) ? 'selected' : '';
                                        echo "<option value='" . $row['id'] . "' $selected>" . htmlspecialchars($row['nom_categorie']) . "</option>";
                                    }
                                }
                                ?>
                            </select>

                        </div>


                    </div>
                    <button type="submit" name="submit">Enregistrer</button>
                </form>



            </section>
            <footer>
                <small>&copy; <?php echo date("Y"); ?>La Suprise C&M Multi-Services. Tous droits réservés.</small>
            </footer>
        </div>
    </div>

    <script>
        // JavaScript pour gérer les sous-menus et la barre latérale
        const menuToggles = document.querySelectorAll('.menu-toggle');
        menuToggles.forEach(toggle => {
            toggle.addEventListener('click', function() {
                const subMenu = this.nextElementSibling;
                const icon = this.querySelector('.accordion-icon');
                if (subMenu.classList.contains('sub-menu-open')) {
                    subMenu.classList.remove('sub-menu-open');
                    icon.classList.remove('rotate');
                } else {
                    document.querySelectorAll('.sub-menu').forEach(menu => menu.classList.remove('sub-menu-open'));
                    document.querySelectorAll('.accordion-icon').forEach(ic => ic.classList.remove('rotate'));
                    subMenu.classList.add('sub-menu-open');
                    icon.classList.add('rotate');
                }
            });
        });

        const hamburgerMenu = document.querySelector('.hamburger-menu');
        const sidebar = document.querySelector('.sidebar');
        hamburgerMenu.addEventListener('click', function() {
            sidebar.classList.toggle('sidebar-open');
        });


        // Fonction pour afficher le message
        function afficherMessage(type, message) {
            const alertContainer = document.getElementById('alert-container');
            if (!alertContainer) return;

            const alertMessage = document.createElement('div');
            alertMessage.className = `alert ${type}`;

            let icon;
            switch (type) {
                case 'success':
                    icon = '<i class="fas fa-check-circle"></i>';
                    break;
                case 'error':
                    icon = '<i class="fas fa-exclamation-circle"></i>';
                    break;
                case 'info':
                    icon = '<i class="fas fa-info-circle"></i>';
                    break;
                case 'warning':
                    icon = '<i class="fas fa-exclamation-triangle"></i>';
                    break;
                default:
                    icon = '';
            }

            alertMessage.innerHTML = `${icon} ${message}`;
            alertContainer.appendChild(alertMessage);

            setTimeout(() => {
                alertMessage.style.opacity = '0';
                setTimeout(() => alertMessage.remove(), 500);
            }, 3000);
        }
        // Vérifier et afficher le message de session au chargement de la page
        document.addEventListener('DOMContentLoaded', function() {
            <?php
            if (isset($_SESSION['message'])) {
                echo "afficherMessage('" . $_SESSION['message']['type'] . "', '" . addslashes($_SESSION['message']['text']) . "');";
                unset($_SESSION['message']);
            }
            ?>
        });
    </script>

</body>

</html>