<?php
session_start();

// Vérifier si l'utilisateur est connecté et est un administrateur
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
  header('Location: ../index.php');
  exit();
}

require_once '../config/database.php';

// Récupérer l'ID du produit à modifier depuis l'URL
if (isset($_GET['id'])) {
  $id_produit = $_GET['id'];

  // Récupérer les informations du produit à partir de la base de données
  $query = "SELECT * FROM produits WHERE id = ?";
  $stmt = $conn->prepare($query);
  $stmt->bind_param("i", $id_produit);
  $stmt->execute();
  $result = $stmt->get_result();
  $produit = $result->fetch_assoc();

  if (!$produit) {
    echo "Produit introuvable.";
    exit();
  }
}

// Gérer la soumission du formulaire pour mettre à jour le stock
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nouveau_stock_caisses = $_POST['nouveau_caisse'];
  $nouveau_stock_unite = $_POST['nouveau_unite'];

  // Calculer le nouveau nombre total de caisses et d'unités
  $total_caisses = $produit['caisse'] + $nouveau_stock_caisses;
  $total_unites = ($produit['quantite_produit'] % 24);

  // Convertir les unités excédentaires en caisses
  $caisses_supplementaires = floor($total_unites / 24);
  $total_caisses += $caisses_supplementaires;
  $total_unites = $total_unites % 24;

  // Calculer la nouvelle quantité totale
  $nouvelle_quantite = ($total_caisses * 24) + $nouveau_stock_unite + $total_unites; 

  // Mettre à jour la valeur du stock dans la base de données
  $update_query = "UPDATE produits SET caisse = ?, quantite_produit = ?, unite = ? WHERE id = ?";
  $update_stmt = $conn->prepare($update_query);
  $update_stmt->bind_param("iiii", $total_caisses, $nouvelle_quantite, $nouveau_stock_unite, $id_produit);


  if ($update_stmt->execute()) {
    // Ajouter un message de succès dans la session
    $_SESSION['message'] = ['type' => 'success', 'text' => 'Stock mis à jour avec succès !'];
    header('Location: ravitaillement_stock.php?');
    exit();
  }
}


?>


<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../css/modifierStock.css">
  <link rel="stylesheet" href="../fontawesome/css/all.min.css">
  <link rel="shortcut icon" href="../images/Logo.png" type="image/x-icon">
  <title>Modifier Stock</title>
  <style>
    /* Conteneur pour les messages */
    #alert-container {
      position: fixed;
      top: 10px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 1000;
    }

    /* Style de base pour les messages */
    .alert {
      padding: 15px;
      margin-bottom: 10px;
      border-radius: 5px;
      color: #fff;
      font-size: 16px;
      opacity: 1;
      transition: opacity 0.5s ease;
      display: flex;
      align-items: center;

    }

    /* Style pour les icônes */
    .alert i {
      margin-right: 10px;
      font-size: 20px;
    }

    /* Style pour les messages de succès */
    .alert.success {
      background-color: #28a745;
      border: 1px solid #1e7e34;
    }

    /* Style pour les messages d'erreur */
    .alert.error {
      background-color: #dc3545;
      border: 1px solid #c82333;
    }

    /* Style pour les messages d'information */
    .alert.info {
      background-color: #17a2b8;
      border: 1px solid #117a8b;
    }

    /* Style pour les messages d'avertissement */
    .alert.warning {
      background-color: #ffc107;
      border: 1px solid #e0a800;
    }
  </style>
</head>

<body>
  <header>
    <i class="fas fa-bars hamburger-menu"></i>
    <h3>La Suprise C&S Multi-Service</h3>
    <a href="../config/logout.php"><i class="fas fa-sign-out-alt"></i></a>
  </header>
  <!-- Div pour le message de succès -->
  <div id="alert-container"></div>



  <div class="dashboard-container">
    <?php include_once '../includes/sidebar.php'; ?>

    <div class="main-content">
      <div class="overlay"></div>
      <section class="content">
        <div class="titre">
          <h3>RAVITAILLEMENT DE STOCK</h3>
        </div>


        <form method="POST" action="">
          <div class="form-row">
            <div class="form-colonne">
              <label for="nom_produit">Nom du produit:</label>
              <input type="text" name="nom_produit" id="nom_produit" value="<?php echo htmlspecialchars($produit['nom_produit']); ?>" readonly>

              <label for="id_categorie">Catégorie:</label>
              <select name="id_categorie" id="id_categorie" disabled>
                <option value="">Sélectionner une catégorie</option>
                <?php
                $categories_query = "SELECT * FROM categories";
                $categories_result = $conn->query($categories_query);
                while ($row = $categories_result->fetch_assoc()) {
                  $selected = ($row['id'] == $produit['id_categorie']) ? 'selected' : '';
                  echo "<option value='" . $row['id'] . "' $selected>" . htmlspecialchars($row['nom_categorie']) . "</option>";
                }
                ?>
              </select>
            </div>

            <div class="form-colonne">
              <label for="caisse">Stock / Caisse initial:</label>
              <input type="number" name="caisse" id="caisse" value="<?php echo $produit['caisse']; ?>" readonly>

              <label for="nouveau_caisse">Nouvelle Caisse / Stock:</label>
              <input type="number" name="nouveau_caisse" id="nouveau_caisse" required>
              <label for="nouveau_unite">Nouvelle Unite / Stock:</label>
              <input type="number" name="nouveau_unite" id="nouveau_unite" required>
            </div>
          </div>
          <button type="submit" name="submit">Enregistrer</button>
        </form>


      </section>
      <footer>
        <small>&copy; <?php echo date("Y"); ?>La Suprise C&M Multi-Services. Tous droits réservés.</small>
      </footer>
    </div>
  </div>

  <script>
    // JavaScript pour gérer les sous-menus et la barre latérale
    const menuToggles = document.querySelectorAll('.menu-toggle');
    menuToggles.forEach(toggle => {
      toggle.addEventListener('click', function() {
        const subMenu = this.nextElementSibling;
        const icon = this.querySelector('.accordion-icon');
        if (subMenu.classList.contains('sub-menu-open')) {
          subMenu.classList.remove('sub-menu-open');
          icon.classList.remove('rotate');
        } else {
          document.querySelectorAll('.sub-menu').forEach(menu => menu.classList.remove('sub-menu-open'));
          document.querySelectorAll('.accordion-icon').forEach(ic => ic.classList.remove('rotate'));
          subMenu.classList.add('sub-menu-open');
          icon.classList.add('rotate');
        }
      });
    });

    const hamburgerMenu = document.querySelector('.hamburger-menu');
    const sidebar = document.querySelector('.sidebar');
    hamburgerMenu.addEventListener('click', function() {
      sidebar.classList.toggle('sidebar-open');
    });


    // Fonction pour afficher le message
    function afficherMessage(type, message) {
      const alertContainer = document.getElementById('alert-container');
      if (!alertContainer) return;

      const alertMessage = document.createElement('div');
      alertMessage.className = `alert ${type}`;

      let icon;
      switch (type) {
        case 'success':
          icon = '<i class="fas fa-check-circle"></i>';
          break;
        case 'error':
          icon = '<i class="fas fa-exclamation-circle"></i>';
          break;
        case 'info':
          icon = '<i class="fas fa-info-circle"></i>';
          break;
        case 'warning':
          icon = '<i class="fas fa-exclamation-triangle"></i>';
          break;
        default:
          icon = '';
      }

      alertMessage.innerHTML = `${icon} ${message}`;
      alertContainer.appendChild(alertMessage);

      setTimeout(() => {
        alertMessage.style.opacity = '0';
        setTimeout(() => alertMessage.remove(), 500);
      }, 3000);
    }
    // Vérifier et afficher le message de session au chargement de la page
    document.addEventListener('DOMContentLoaded', function() {
      <?php
      if (isset($_SESSION['message'])) {
        echo "afficherMessage('" . $_SESSION['message']['type'] . "', '" . addslashes($_SESSION['message']['text']) . "');";
        unset($_SESSION['message']);
      }
      ?>
    });
  </script>

</body>

</html>