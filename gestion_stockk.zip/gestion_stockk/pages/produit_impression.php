<?php
session_start();

/// Vérifier si l'utilisateur est connecté et est un administrateur
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
  header('Location: ../index.php');
  exit();
}
require_once '../config/database.php';

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nomClient = $_POST['nomClient'];
  $type = $_POST['type'];
  $description = $_POST['description'];
  $quantite = $_POST['quantite'];
  $prix = $_POST['prix'];
  $prix_total = $quantite * $prix; // Calcul du prix total
  $date_vente = date('Y-m-d H:i:s');
  $nom_utilisateur = $_SESSION['nom_utilisateur']; // Récupération du nom d'utilisateur de la session

  $sql = "INSERT INTO produit_impression (nom_client, type_produit, description, quantite, prix, prix_total, date_vente, nom_utilisateur) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("sssiidss", $nomClient, $type, $description, $quantite, $prix, $prix_total, $date_vente, $nom_utilisateur);

  if ($stmt->execute()) {
    $_SESSION['message'] = ['type' => 'success', 'text' => 'Vente enregistrée avec succès!'];
  } else {
    $_SESSION['message'] = ['type' => 'error', 'text' => 'Erreur lors de l\'enregistrement de la vente.'];
  }

  $stmt->close();
  header('Location: produit_impression.php');
  exit();
}

?>

<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../css/produitImpression.css">
  <link rel="stylesheet" href="../fontawesome/css/all.min.css">
  <link rel="shortcut icon" href="../images/Logo.png" type="image/x-icon">
  <title>Vente produit impression</title>
  <style>
    /* Conteneur pour les messages */
    #alert-container {
      position: fixed;
      top: 10px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 1000;
    }

    /* Style de base pour les messages */
    .alert {
      padding: 15px;
      margin-bottom: 10px;
      border-radius: 5px;
      color: #fff;
      font-size: 16px; 
      opacity: 1;
      transition: opacity 0.5s ease;
      display: flex;
      align-items: center;

    }

    /* Style pour les icônes */
    .alert i {
      margin-right: 10px;
      font-size: 20px;
    }

    /* Style pour les messages de succès */
    .alert.success {
      background-color: #28a745;
      border: 1px solid #1e7e34;
    }

    /* Style pour les messages d'erreur */
    .alert.error {
      background-color: #dc3545;
      border: 1px solid #c82333;
    }

    /* Style pour les messages d'information */
    .alert.info {
      background-color: #17a2b8;
      border: 1px solid #117a8b;
    }

    /* Style pour les messages d'avertissement */
    .alert.warning {
      background-color: #ffc107;
      border: 1px solid #e0a800;
    }
  </style>
</head>

<body>
  <header>
    <i class="fas fa-bars hamburger-menu"></i>
    <h3>La Suprise C&S Multi-Service</h3>
    <a href="../config/logout.php"><i class="fas fa-sign-out-alt"></i></a>
  </header>

  <!-- Div pour le message de succès -->
  <div id="alert-container"></div>

  <div class="dashboard-container">
    <?php include_once '../includes/sidebar.php'; ?>
    <div class="main-content">
      <div class="overlay"></div>
      <section class="content">
        <div class="titre">
          <h3>Vente des produits d'impression</h3>
        </div>
        <form method="POST" action="">
          <label for="nomClient">Nom Client:</label>
          <input type="text" id="nomClient" name="nomClient" required>

          <label for="type">Produits:</label>
          <select name="type" id="type" required>
            <option value="">Choisir...</option>
            <option value="Papier">Papier</option>
            <option value="Enveloppe">Enveloppe Blanc</option>
            <option value="Enveloppe">Enveloppe Jaune</option>
            <option value="Chemiset">Chemise</option>
            <option value="Chemiset">Chemise en Plastique</option>
            <option value="Bristol">Bristol</option>
            <option value="Plume">Plume</option>
            <option value="Enveloppe">Cahier 18 page</option>
            <option value="Enveloppe">Cahier 36 page</option>
            <option value="Enveloppe">Cahier 96 page</option>
            <option value="Enveloppe">Marquer</option>
            <option value="Autres">Autres..</option>
          </select>

          <label for="description">Description:</label>
          <textarea name="description" id="description"></textarea>

          <label for="quantite">Quantité:</label>
          <input type="number" id="quantite" name="quantite" required onchange="updatePrixTotal()">

          <label for="prix">Prix unitaire:</label>
          <input type="number" id="prix" name="prix" step="0.01" required onchange="updatePrixTotal()">

          <label for="prix_total">Prix total:</label>
          <input type="number" id="prix_total" name="prix_total" step="0.01" readonly>

          <button type="submit"><i class="fas fa-money-bill-wave"></i> Paiement</button>
        </form>
      </section>
      <footer>
        <small>&copy; <?php echo date("Y"); ?>La Suprise C&M Multi-Services. Tous droits réservés.</small>
      </footer>
    </div>
  </div>

  <script src="../js/script.js"></script>
  <script>
    // Fonction pour afficher le message
    function afficherMessage(type, message) {
      const alertContainer = document.getElementById('alert-container');
      if (!alertContainer) return;

      const alertMessage = document.createElement('div');
      alertMessage.className = `alert ${type}`;

      let icon;
      switch (type) {
        case 'success':
          icon = '<i class="fas fa-check-circle"></i>';
          break;
        case 'error':
          icon = '<i class="fas fa-exclamation-circle"></i>';
          break;
        case 'info':
          icon = '<i class="fas fa-info-circle"></i>';
          break;
        case 'warning':
          icon = '<i class="fas fa-exclamation-triangle"></i>';
          break;
        default:
          icon = '';
      }

      alertMessage.innerHTML = `${icon} ${message}`;
      alertContainer.appendChild(alertMessage);

      setTimeout(() => {
        alertMessage.style.opacity = '0';
        setTimeout(() => alertMessage.remove(), 500);
      }, 3000);
    }
    // Vérifier et afficher le message de session au chargement de la page
    document.addEventListener('DOMContentLoaded', function() {
      <?php
      if (isset($_SESSION['message'])) {
        echo "afficherMessage('" . $_SESSION['message']['type'] . "', '" . addslashes($_SESSION['message']['text']) . "');";
        unset($_SESSION['message']);
      }
      ?>
    });

    // Nouvelle fonction pour mettre à jour le prix total
    function updatePrixTotal() {
      var quantite = parseFloat(document.getElementById('quantite').value);
      var prix = parseFloat(document.getElementById('prix').value);
      var prixTotal = quantite * prix;
      if (!isNaN(prixTotal)) {
        document.getElementById('prix_total').value = prixTotal.toFixed(2);
      } else {
        document.getElementById('prix_total').value = '';
      }
    }

    // Modifier les écouteurs d'événements
    document.addEventListener('DOMContentLoaded', function() {
      document.getElementById('quantite').addEventListener('input', updatePrixTotal);
      document.getElementById('prix').addEventListener('input', updatePrixTotal);

      <?php
      if (isset($_SESSION['message'])) {
        echo "afficherMessage('" . $_SESSION['message']['type'] . "', '" . addslashes($_SESSION['message']['text']) . "');";
        unset($_SESSION['message']);
      }
      ?>

      // Appeler updatePrixTotal une fois au chargement de la page
      updatePrixTotal();
    });
  </script>

</body>

</html>