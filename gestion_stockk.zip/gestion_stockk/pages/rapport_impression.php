<?php
session_start();
// Vérifier si l'utilisateur est connecté et est un administrateur
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
  header('Location: ../index.php');
  exit();
}
require_once '../config/database.php';

// Fonction pour générer le rapport
function genererRapport($conn, $type)
{
  $sql = "";
  switch ($type) {
    case 'journalier':
      $sql = "SELECT DATE(date_vente) AS date, SUM(total_ventes) AS total_ventes FROM (
                SELECT date_vente AS date_vente, prix_total AS total_ventes FROM produit_impression WHERE is_deleted = 0
                UNION ALL
                SELECT date_impression AS date_vente, prix AS total_ventes FROM service_impression WHERE is_deleted = 0
              ) AS combined_sales
              WHERE DATE(date_vente) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
              GROUP BY DATE(date_vente) ORDER BY date DESC";
      break;
    case 'mensuel':
      $sql = "SELECT DATE_FORMAT(date_vente, '%Y-%m') AS mois, SUM(total_ventes) AS total_ventes FROM (
                SELECT date_vente, prix_total AS total_ventes FROM produit_impression WHERE is_deleted = 0
                UNION ALL
                SELECT date_impression AS date_vente, prix AS total_ventes FROM service_impression WHERE is_deleted = 0
              ) AS combined_sales
              WHERE date_vente >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
              GROUP BY mois ORDER BY mois DESC";
      break;
    case 'annuel':
      $sql = "SELECT YEAR(date_vente) AS annee, SUM(total_ventes) AS total_ventes FROM (
                SELECT date_vente, prix_total AS total_ventes FROM produit_impression WHERE is_deleted = 0
                UNION ALL
                SELECT date_impression AS date_vente, prix AS total_ventes FROM service_impression WHERE is_deleted = 0
              ) AS combined_sales
              GROUP BY annee ORDER BY annee DESC LIMIT 5";
      break;
  }

  $result = $conn->query($sql);
  return $result->fetch_all(MYSQLI_ASSOC);
}

$rapport = null;
$type_rapport = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $type_rapport = $_POST['type_rapport'];
  $rapport = genererRapport($conn, $type_rapport);
}


?>

<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Generer Rapport</title>
  <link rel="stylesheet" href="../css/genererRapport.css">
  <link rel="stylesheet" href="../fontawesome/css/all.min.css">
  <link rel="shortcut icon" href="../images/Logo.png" type="image/x-icon">
</head>

<body>
  <header class="no-print">
    <i class="fas fa-bars hamburger-menu"></i>
    <h3>La Suprise C&S Multi-Service</h3>
    <a href="../config/logout.php"><i class="fas fa-sign-out-alt"></i></a>
  </header>

  <div class="dashboard-container">
    <?php include_once '../includes/sidebar.php'; ?>

    <div class="main-content">
      <div class="overlay"></div>
      <section class="content">
        <h2>Générer rapport de ventes impression et service</h2>
        <form method="POST" action="">
          <select name="type_rapport" required>
            <option value="">Sélectionnez le type de rapport</option>
            <option value="journalier">Rapport journalier</option>
            <option value="mensuel">Rapport mensuel</option>
            <option value="annuel">Rapport annuel</option>
          </select>
          <button type="submit">Générer le rapport</button>
        </form>

        <?php if ($rapport): ?>
          <div class="rapport">
            <h3>Rapport <?php echo ucfirst($type_rapport); ?></h3>
            <table>
              <thead>
                <tr>
                  <th class="text-left">Période</th>
                  <th class="text-right">Total des ventes</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($rapport as $ligne): ?>
                  <tr>
                    <td><?php echo $ligne['date'] ?? $ligne['mois'] ?? $ligne['annee']; ?></td>
                    <td><?php echo number_format($ligne['total_ventes'], 2, ',', ' '); ?> HTG</td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>




      </section>
      <footer no-print>
        <small>&copy; <?php echo date("Y"); ?>La Suprise C&M Multi-Services. Tous droits réservés.</small>
      </footer>
    </div>


  </div>

  <script src="../js/script.js"></script>
</body>

</html>

<?php
$conn->close();
?>