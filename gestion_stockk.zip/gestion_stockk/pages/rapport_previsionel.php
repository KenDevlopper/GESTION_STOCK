<?php
session_start();
// Vérifier si l'utilisateur est connecté et est un administrateur
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
  header('Location: ../index.php');
  exit();
}
require_once '../config/database.php';

// Fonction pour générer le rapport
function genererRapport($conn, $nom_produit)
{
  $sql = "SELECT nom_produit, prix_unite, prix_caisse, quantite_produit, caisse 
            FROM produits 
            WHERE nom_produit = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("s", $nom_produit);
  $stmt->execute();
  $result = $stmt->get_result();
  $row = $result->fetch_assoc();

  if ($row) {
    $total_unite = $row['prix_unite'] * ($row['quantite_produit']);
    $total_caisse = $row['prix_caisse'] * $row['caisse'];

    return [
      'nom_produit' => $row['nom_produit'],
      'total_unite' => $total_unite,
      'total_caisse' => $total_caisse
    ];
  }
  return null;
}

$rapport = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nom_produit'])) {
  $rapport = genererRapport($conn, $_POST['nom_produit']);
}

// Récupérer la liste des produits pour le select
$sql_produits = "SELECT nom_produit FROM produits";
$result_produits = $conn->query($sql_produits);

?>

<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title> Rapport Prévisionel</title>
  <link rel="stylesheet" href="../css/genererRapport.css">
  <link rel="stylesheet" href="../fontawesome/css/all.min.css">
  <link rel="shortcut icon" href="../images/Logo.png" type="image/x-icon">
</head>

<body>
  <header class="no-print">
    <i class="fas fa-bars hamburger-menu"></i>
    <h3>LaSuprise C&S Multi-Service</h3>
    <a href="../config/logout.php"><i class="fas fa-sign-out-alt"></i></a>
  </header>

  <div class="dashboard-container">
    <?php include_once '../includes/sidebar.php'; ?>

    <div class="main-content">
      <div class="overlay"></div>
      <section class="content">
        <h2> Rapport Prévisionel</h2>
        <form method="POST" action="">
          <select name="nom_produit" required>
            <option value="">Sélectionnez le nom de produit</option>
            <?php while ($row = $result_produits->fetch_assoc()): ?>
              <option value="<?php echo htmlspecialchars($row['nom_produit']); ?>"><?php echo htmlspecialchars($row['nom_produit']); ?></option>
            <?php endwhile; ?>
          </select>
          <button type="submit">Générer le rapport</button>
        </form>

        <?php if ($rapport): ?>
          <div class="rapport">
            <h3>Rapport Prévisionel</h3>
            <table>
              <thead>
                <tr>
                  <th class="text-left">Nom Produit</th>
                  <th class="text-right">Vente par Unité</th>
                  <th class="text-right">Vente par Caisse</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td class="text-left"><?php echo htmlspecialchars($rapport['nom_produit']); ?></td>
                  <td class="text-right" style="font-weight: bold;"><?php echo number_format($rapport['total_unite'], 2); ?> HTG</td>
                  <td class="text-right" style="color: #000;"><?php echo number_format($rapport['total_caisse'], 2); ?> HTG</td>
                </tr>
              </tbody>
            </table>
          </div>
        <?php endif; ?>

      </section>
      <footer no-print>
        <small>&copy; <?php echo date("Y"); ?> Suprise C&M Multi-Services. Tous droits réservés.</small>
      </footer>
    </div>


  </div>

  <script src="../js/script.js"></script>
</body>

</html>

<?php
$conn->close();
?>