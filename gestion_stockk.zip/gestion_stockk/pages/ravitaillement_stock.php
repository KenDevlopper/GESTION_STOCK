<?php
session_start();

// Vérifier si l'utilisateur est connecté et est un administrateur
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
  header('Location: ../index.php');
  exit();
}

require_once '../config/database.php';

// Vérifier si un mot-clé de recherche est envoyé
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Préparer la requête pour récupérer les produits
$sql = "SELECT p.id, p.nom_produit, p.description, p.prix_unite, p.caisse,p.prix_caisse, p.quantite_produit, c.nom_categorie 
        FROM produits p
        JOIN categories c ON p.id_categorie = c.id";

// Ajouter la condition de recherche si un mot-clé est fourni
// Ajouter cette fonction pour obtenir les suggestions
function getSuggestions($conn, $search)
{
  $sql = "SELECT DISTINCT nom_produit FROM produits WHERE nom_produit LIKE ? LIMIT 5";
  $stmt = $conn->prepare($sql);
  $search_param = $search . '%';
  $stmt->bind_param("s", $search_param);
  $stmt->execute();
  $result = $stmt->get_result();
  $suggestions = [];
  while ($row = $result->fetch_assoc()) {
    $suggestions[] = $row['nom_produit'];
  }
  return $suggestions;
}
// Vérifier si une requête AJAX est faite pour les suggestions
if (isset($_GET['ajax']) && $_GET['ajax'] == 'suggestions') {
  $search = isset($_GET['search']) ? trim($_GET['search']) : '';
  $suggestions = getSuggestions($conn, $search);
  echo json_encode($suggestions);
  exit;
}


// Modifier la requête SQL pour inclure la recherche par catégorie
$sql = "SELECT p.id, p.nom_produit, p.description, p.prix_unite, p.caisse, p.prix_caisse, p.quantite_produit, c.nom_categorie 
        FROM produits p
        JOIN categories c ON p.id_categorie = c.id";

if (!empty($search)) {
  $sql .= " WHERE p.nom_produit LIKE ? OR p.description LIKE ? OR c.nom_categorie LIKE ?";
  $stmt = $conn->prepare($sql);
  $search_param = '%' . $search . '%';
  $stmt->bind_param("sss", $search_param, $search_param, $search_param);
} else {
  $stmt = $conn->prepare($sql);
}
$stmt->execute();
$result = $stmt->get_result();

?>
<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../css/listerProduit.css">
  <link rel="stylesheet" href="../fontawesome/css/all.min.css">
  <link rel="shortcut icon" href="../images/Logo.png" type="image/x-icon">
  <title>Ravitaillement de Stock</title>
  <style>
    /* Conteneur pour les messages */
    #alert-container {
      position: fixed;
      top: 10px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 1000;
    }

    /* Style de base pour les messages */
    .alert {
      padding: 15px;
      margin-bottom: 10px;
      border-radius: 5px;
      color: #fff;
      font-size: 16px;
      opacity: 1;
      transition: opacity 0.5s ease;
      display: flex;
      align-items: center;

    }

    /* Style pour les icônes */
    .alert i {
      margin-right: 10px;
      font-size: 20px;
    }

    /* Style pour les messages de succès */
    .alert.success {
      background-color: #28a745;
      border: 1px solid #1e7e34;
    }

    /* Style pour les messages d'erreur */
    .alert.error {
      background-color: #dc3545;
      border: 1px solid #c82333;
    }

    /* Style pour les messages d'information */
    .alert.info {
      background-color: #17a2b8;
      border: 1px solid #117a8b;
    }

    /* Style pour les messages d'avertissement */
    .alert.warning {
      background-color: #ffc107;
      border: 1px solid #e0a800;
    }

    .search-container {
      flex: 30;
      position: relative;
      display: inline-block;
    }

    #suggestions {
      position: absolute;
      top: 100%;
      left: 0;
      width: 100%;
      max-height: 200px;
      overflow-y: auto;
      background-color: white;
      border: 1px solid #ddd;
      border-top: none;
      list-style-type: none;
      padding: 0;
      margin: 0;
      z-index: 1000;
    }

    #suggestions li {
      padding: 10px;
      cursor: pointer;
    }

    #suggestions li:hover {
      background-color: #f0f0f0;
    }
  </style>
</head>

<body>
  <header>
    <i class="fas fa-bars hamburger-menu"></i>
    <h3>La Suprise C&S Multi-Service</h3>
    <a href="../config/logout.php"><i class="fas fa-sign-out-alt"></i></a>
  </header>

  <!-- Div pour le message de succès -->
  <div id="alert-container"></div>


  <div class="dashboard-container">
    <?php include_once '../includes/sidebar.php'; ?>

    <div class="main-content">
      <div class="overlay"></div>
      <section class="content">
        <!-- Formulaire de recherche -->
        <form method="GET" action="ravitaillement_stock.php" id="searchForm">
          <div class="search-container">
            <input type="text" name="search" id="searchInput" placeholder="Rechercher un produit..." value="<?php echo htmlspecialchars($search); ?>" autocomplete="off" />
            <ul id="suggestions"></ul>
          </div>
          <button class="btnRecherche" type="submit"><i class="fas fa-search"></i> Rechercher</button>
        </form>
        <hr>




        <!-- Tableau des produits -->
        <div class="table-container">
          <table class="responsive-table">
            <thead>
              <div class="tabHead">
                <h3>Ravitaillement de stock</h3>
              </div>
              <tr>
                <th>ID</th>
                <th>Nom du produit</th>
                <th>Description</th>
                <th>Prix unitaire</th>
                <th>Stock</th>
                <th>Prix / Caisse</th>
                <th>Quantité</th>
                <th>Catégorie</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                  <tr>
                    <td data-label='ID'><?php echo $row['id']; ?></td>
                    <td data-label='Nom'><?php echo htmlspecialchars($row['nom_produit']); ?></td>
                    <td data-label='Description'><?php echo htmlspecialchars($row['description']); ?></td>
                    <td data-label='Prix Unitaire'><?php echo number_format($row['prix_unite'], 2); ?> HTG</td>
                    <td data-label='Stock'><?php echo $row['caisse']; ?></td>
                    <td data-label='Prix/Caisse'><?php echo number_format($row['prix_caisse'], 2); ?> HTG</td>
                    <td data-label='Quantite'><?php echo $row['quantite_produit']; ?></td>
                    <td data-label='Categorie'><?php echo htmlspecialchars($row['nom_categorie']); ?></td>
                    <td data-label='Actions'>
                      <div class="Btn">
                        <a href="modifier_stock.php?id=<?php echo $row['id']; ?>" class="btn-modifier"><i class="fas fa-edit"></i> Ravitaillement</a>

                      </div>
                    </td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr>
                  <td colspan="8">Aucun produit trouvé.</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>




      </section>
      <footer>
        <small>&copy; <?php echo date("Y"); ?>La Suprise C&M Multi-Services. Tous droits réservés.</small>
      </footer>
    </div>
  </div>

  <script>
    // JavaScript pour gérer les sous-menus et la barre latérale
    const menuToggles = document.querySelectorAll('.menu-toggle');
    menuToggles.forEach(toggle => {
      toggle.addEventListener('click', function() {
        const subMenu = this.nextElementSibling;
        const icon = this.querySelector('.accordion-icon');
        if (subMenu.classList.contains('sub-menu-open')) {
          subMenu.classList.remove('sub-menu-open');
          icon.classList.remove('rotate');
        } else {
          document.querySelectorAll('.sub-menu').forEach(menu => menu.classList.remove('sub-menu-open'));
          document.querySelectorAll('.accordion-icon').forEach(ic => ic.classList.remove('rotate'));
          subMenu.classList.add('sub-menu-open');
          icon.classList.add('rotate');
        }
      });
    });

    const hamburgerMenu = document.querySelector('.hamburger-menu');
    const sidebar = document.querySelector('.sidebar');
    hamburgerMenu.addEventListener('click', function() {
      sidebar.classList.toggle('sidebar-open');
    });


    document.addEventListener('DOMContentLoaded', function() {
      const urlParams = new URLSearchParams(window.location.search);
      if (urlParams.has('success')) {
        const successMessage = document.getElementById('success-message');
        if (successMessage) {
          let message = '';
          if (urlParams.get('success') === 'true') {
            message = 'Stock mis à jour avec succès !';
          }
          successMessage.innerHTML = '<i class="fas fa-check-circle"></i> ' + message;
          successMessage.style.display = 'block';
          setTimeout(function() {
            successMessage.style.display = 'none';
          }, 3000); // 3 secondes
        }
      }
    });
    const searchInput = document.getElementById('searchInput');
    const suggestionsList = document.getElementById('suggestions');
    const searchForm = document.getElementById('searchForm');

    searchInput.addEventListener('input', function() {
      const search = this.value.trim();
      if (search.length > 0) {
        fetch(`ravitaillement_stock.php?ajax=suggestions&search=${encodeURIComponent(search)}`)
          .then(response => response.json())
          .then(data => {
            suggestionsList.innerHTML = '';
            data.forEach(suggestion => {
              const li = document.createElement('li');
              li.textContent = suggestion;
              li.addEventListener('click', function() {
                searchInput.value = this.textContent;
                suggestionsList.innerHTML = '';
                searchForm.submit();
              });
              suggestionsList.appendChild(li);
            });
          });
      } else {
        suggestionsList.innerHTML = '';
        searchForm.submit();
      }
    });

    document.addEventListener('click', function(e) {
      if (e.target !== searchInput && e.target !== suggestionsList) {
        suggestionsList.innerHTML = '';
      }
    });

    // Fonction pour afficher le message
    function afficherMessage(type, message) {
      const alertContainer = document.getElementById('alert-container');
      if (!alertContainer) return;

      const alertMessage = document.createElement('div');
      alertMessage.className = `alert ${type}`;

      let icon;
      switch (type) {
        case 'success':
          icon = '<i class="fas fa-check-circle"></i>';
          break;
        case 'error':
          icon = '<i class="fas fa-exclamation-circle"></i>';
          break;
        case 'info':
          icon = '<i class="fas fa-info-circle"></i>';
          break;
        case 'warning':
          icon = '<i class="fas fa-exclamation-triangle"></i>';
          break;
        default:
          icon = '';
      }

      alertMessage.innerHTML = `${icon} ${message}`;
      alertContainer.appendChild(alertMessage);

      setTimeout(() => {
        alertMessage.style.opacity = '0';
        setTimeout(() => alertMessage.remove(), 500);
      }, 3000);
    }
    // Vérifier et afficher le message de session au chargement de la page
    document.addEventListener('DOMContentLoaded', function() {
      <?php
      if (isset($_SESSION['message'])) {
        echo "afficherMessage('" . $_SESSION['message']['type'] . "', '" . addslashes($_SESSION['message']['text']) . "');";
        unset($_SESSION['message']);
      }
      ?>
    });
  </script>

</body>

</html>