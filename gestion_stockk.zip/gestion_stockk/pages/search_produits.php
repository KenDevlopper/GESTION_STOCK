<?php
// Inclure la connexion à la base de données
require_once '../config/database.php';

$search = '';

if (isset($_GET['search']) && !empty($_GET['search'])) {
  $search = htmlspecialchars($_GET['search']);

  // Préparer la requête pour rechercher les produits correspondant
  $stmt = $conn->prepare("SELECT * FROM produits WHERE nom_produit LIKE ?");
  $searchParam = '%' . $search . '%';
  $stmt->bind_param('s', $searchParam);
  $stmt->execute();
  $result = $stmt->get_result();

  $products = [];
  while ($row = $result->fetch_assoc()) {
    $products[] = $row;
  }

  // Retourner les résultats sous forme de JSON
  echo json_encode($products);
  $stmt->close();
}
