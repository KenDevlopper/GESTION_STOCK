<?php
session_start();
require_once '../config/database.php';

// Vérifier si l'utilisateur est connecté et est un administrateur
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
  header('Location: index.php');
  exit();
}
// Traitement du formulaire de changement de nom d'utilisateur
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_username'])) {
  $new_username = trim($_POST['new_username']);
  $user_id = $_SESSION['user_id'];

  if (!empty($new_username)) {
    $stmt = $conn->prepare("UPDATE utilisateurs SET nom_utilisateur = ? WHERE id = ?");
    $stmt->bind_param("si", $new_username, $user_id);
    if ($stmt->execute()) {
      $_SESSION['nom_utilisateur'] = $new_username;
      $_SESSION['message'] = ['type' => 'success', 'text' => 'Nom utilisateur mis à jour avec succès.'];
    } else {
      $_SESSION['message'] = ['type' => 'error', 'text' => 'Erreur lors de la mise à jour du nom Utilisateur.'];
    }
    $stmt->close();
  } else {
    $_SESSION['message'] = ['type' => 'error', 'text' => 'Le nouveau  nom Utilisateur ne peut pas être vide.'];
  }
  header('Location: securite.php');
  exit();
}

// Traitement du formulaire de changement de mot de passe
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
  $current_password = $_POST['current_password'];
  $new_password = $_POST['new_password'];
  $confirm_password = $_POST['confirm_password'];
  $user_id = $_SESSION['user_id'];

  if ($new_password === $confirm_password) {
    $stmt = $conn->prepare("SELECT mot_de_passe FROM utilisateurs WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if (password_verify($current_password, $user['mot_de_passe'])) {
      $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
      $update_stmt = $conn->prepare("UPDATE utilisateurs SET mot_de_passe = ? WHERE id = ?");
      $update_stmt->bind_param("si", $hashed_password, $user_id);
      if ($update_stmt->execute()) {
        $_SESSION['message'] = ['type' => 'success', 'text' => 'Mot de passe mis à jour avec succès.'];
      } else {
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Erreur lors de la mise à jour du mot de passe.'];
      }
      $update_stmt->close();
    } else {
      $_SESSION['message'] = ['type' => 'error', 'text' => 'Le mot de passe actuel est incorrect.'];
    }
    $stmt->close();
  } else {
    $_SESSION['message'] = ['type' => 'error', 'text' => 'Les nouveaux mots de passe ne correspondent pas.'];
  }
  header('Location: securite.php');
  exit();
}




?>

<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Securite</title>
  <link rel="stylesheet" href="../css/securite.css">
  <link rel="stylesheet" href="../fontawesome/css/all.min.css">
  <link rel="shortcut icon" href="../images/Logo.png" type="image/x-icon">
  <style>
    /* Conteneur pour les messages */
    #alert-container {
      position: fixed;
      top: 10px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 1000;
    }

    /* Style de base pour les messages */
    .alert {
      padding: 15px;
      margin-bottom: 10px;
      border-radius: 5px;
      color: #fff;
      font-size: 16px;
      opacity: 1;
      transition: opacity 0.5s ease;
      display: flex;
      align-items: center;

    }

    /* Style pour les icônes */
    .alert i {
      margin-right: 10px;
      font-size: 20px;
    }

    /* Style pour les messages de succès */
    .alert.success {
      background-color: #28a745;
      border: 1px solid #1e7e34;
    }

    /* Style pour les messages d'erreur */
    .alert.error {
      background-color: #dc3545;
      border: 1px solid #c82333;
    }

    /* Style pour les messages d'information */
    .alert.info {
      background-color: #17a2b8;
      border: 1px solid #117a8b;
    }

    /* Style pour les messages d'avertissement */
    .alert.warning {
      background-color: #ffc107;
      border: 1px solid #e0a800;
    }
  </style>
</head>

<body>
  <header>
    <i class="fas fa-bars hamburger-menu"></i>
    <h3>Suprise C&S Multi-Service</h3>
    <a href="../config/logout.php"><i class="fas fa-sign-out-alt"></i></a>
  </header>

  <!-- Div pour le message de succès -->
  <div id="alert-container"></div>

  <div class="dashboard-container">
    <?php include_once '../includes/sidebar.php'; ?>


    <div class="main-content">
      <div class="overlay"></div>
      <section class="content">
        <div class="container">

          <!--  <h2>Paramètres de sécurité</h2> -->

          <?php if (isset($_SESSION['success_message'])): ?>
            <div class="success-message"><?php echo $_SESSION['success_message'];
                                          unset($_SESSION['success_message']); ?></div>
          <?php endif; ?>

          <?php if (isset($_SESSION['error_message'])): ?>
            <div class="error-message"><?php echo $_SESSION['error_message'];
                                        unset($_SESSION['error_message']); ?></div>
          <?php endif; ?>

          <form action="securite.php" method="post">
            <h3>Changer le nom d'utilisateur</h3>
            <input type="text" name="new_username" placeholder="Nouveau nom d'utilisateur" required>
            <button type="submit" name="change_username">Changer le nom d'utilisateur</button>
          </form>

          <form action="securite.php" method="post">
            <h3>Changer le mot de passe</h3>
            <input type="password" name="current_password" placeholder="Mot de passe actuel" required>
            <input type="password" name="new_password" placeholder="Nouveau mot de passe" required>
            <input type="password" name="confirm_password" placeholder="Confirmer le nouveau mot de passe" required>
            <button type="submit" name="change_password">Changer le mot de passe</button>
          </form>

        </div>
      </section>
      <footer n>
        <small>&copy; <?php echo date("Y"); ?> Suprise C&M Multi-Services. Tous droits réservés.</small>
      </footer>
    </div>


  </div>

  <script src="../js/script.js"></script>
  <script>
    // Fonction pour afficher le message
    function afficherMessage(type, message) {
      const alertContainer = document.getElementById('alert-container');
      if (!alertContainer) return;

      const alertMessage = document.createElement('div');
      alertMessage.className = `alert ${type}`;

      let icon;
      switch (type) {
        case 'success':
          icon = '<i class="fas fa-check-circle"></i>';
          break;
        case 'error':
          icon = '<i class="fas fa-exclamation-circle"></i>';
          break;
        case 'info':
          icon = '<i class="fas fa-info-circle"></i>';
          break;
        case 'warning':
          icon = '<i class="fas fa-exclamation-triangle"></i>';
          break;
        default:
          icon = '';
      }

      alertMessage.innerHTML = `${icon} ${message}`;
      alertContainer.appendChild(alertMessage);

      setTimeout(() => {
        alertMessage.style.opacity = '0';
        setTimeout(() => alertMessage.remove(), 500);
      }, 3000);
    }
    // Vérifier et afficher le message de session au chargement de la page
    document.addEventListener('DOMContentLoaded', function() {
      <?php
      if (isset($_SESSION['message'])) {
        echo "afficherMessage('" . $_SESSION['message']['type'] . "', '" . addslashes($_SESSION['message']['text']) . "');";
        unset($_SESSION['message']);
      }
      ?>
    });
  </script>
</body>

</html>

<?php
$conn->close();
?>