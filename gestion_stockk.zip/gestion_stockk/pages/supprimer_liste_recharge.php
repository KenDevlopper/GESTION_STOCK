<?php
session_start();
require_once '../config/database.php';



if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Préparer la requête SQL pour supprimer toutes les recharges
  $sql = "DELETE FROM service_recharge";

  // Exécuter la requête
  if ($conn->query($sql) === TRUE) {
    $response = ['success' => true, 'message' => 'Toutes la liste de service recharge ont été supprimées avec succès.'];
  } else {
    $response = ['success' => false, 'message' => 'Erreur lors de la suppression des services recharge: ' . $conn->error];
  }

  // Fermer la connexion à la base de données
  $conn->close();

  // Renvoyer la réponse en format JSON
  header('Content-Type: application/json');
  echo json_encode($response);
} else {
  // Si la méthode de requête n'est pas POST, renvoyer une erreur
  http_response_code(405);
  echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
}
