<?php
session_start();
require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Préparer la requête SQL pour marquer toutes les ventes comme supprimées
  $sql_ventes = "UPDATE ventes SET is_deleted = 1";
  $sql_ventes_eau = "UPDATE ventes_eau SET is_deleted = 1";

  // Exécuter la requête pour les ventes
  $response_ventes = $conn->query($sql_ventes);
  // Exécuter la requête pour les ventes d'eau
  $response_ventes_eau = $conn->query($sql_ventes_eau);

  // Vérifier le succès de la suppression
  if ($response_ventes === TRUE && $response_ventes_eau === TRUE) {
    $response = ['success' => true, 'message' => 'Toutes les ventes et ventes d\'eau ont été marquées comme supprimées avec succès.'];
  } else {
    $error_message = 'Erreur lors de la suppression : ';
    if ($response_ventes !== TRUE) {
      $error_message .= 'Ventes: ' . $conn->error . ' ';
    }
    if ($response_ventes_eau !== TRUE) {
      $error_message .= 'Ventes d\'eau: ' . $conn->error . ' ';
    }
    $response = ['success' => false, 'message' => $error_message];
  }

  // Fermer la connexion à la base de données
  $conn->close();

  // Renvoyer la réponse en format JSON
  header('Content-Type: application/json');
  echo json_encode($response);
} else {
  // Si la méthode de requête n'est pas POST, renvoyer une erreur
  http_response_code(405);
  echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
}
