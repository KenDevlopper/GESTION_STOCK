<?php
// Configuration de la base de données
$host = 'localhost';
$db = 'votre_base_de_donnees';
$user = 'votre_utilisateur';
$pass = 'votre_mot_de_passe';

// Connexion à la base de données
try {
  $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  // Informations de l'utilisateur à pré-enregistrer
  $username = '';
  $password = 'votre_mot_de_passe'; // Mot de passe en clair (pour le moment)
  $role = 'votre_role'; // Par exemple, 'admin', 'utilisateur', etc.

  // Hachage du mot de passe
  $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

  // Préparation de la requête d'insertion
  $stmt = $pdo->prepare("INSERT INTO utilisateurs (nom_utilisateur, mot_de_passe, role) VALUES (:username, :password, :role)");

  // Liaison des paramètres
  $stmt->bindParam(':username', $username);
  $stmt->bindParam(':password', $hashedPassword);
  $stmt->bindParam(':role', $role);

  // Exécution de la requête
  $stmt->execute();

  echo "Utilisateur pré-enregistré avec succès.";
} catch (PDOException $e) {
  echo "Erreur : " . $e->getMessage();
}
